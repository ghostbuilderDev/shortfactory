SHORTFACTORY V7 STOCKVIDEO AGENT — HTMLTOAPK

OBJECTIF
Créer automatiquement une vidéo de 30 secondes avec de vrais clips HD gratuits.

MOTEURS
- Pexels Video API : moteur principal.
- Pixabay Video API : secours facultatif.
- Import local : secours si un hébergeur bloque le téléchargement dans la WebView.

FONCTIONNEMENT
1. L'utilisateur saisit ses propres clés API gratuites.
2. L'agent crée six scènes et six recherches vidéo.
3. L'application interroge Pexels.
4. Pixabay complète les scènes avec peu de résultats.
5. ShortFactory sélectionne les clips les plus adaptés au format.
6. L'utilisateur peut remplacer chaque clip.
7. Les clips sont téléchargés temporairement dans l'application.
8. ShortFactory recadre, coupe et assemble six extraits de cinq secondes.
9. Les sous-titres, les transitions et les crédits sont ajoutés.
10. La vidéo finale est exportée en MP4 si la WebView le permet, sinon en WebM.

RÉGLAGES HTMLTOAPK
- Fichier principal : index.html
- Internet : activé
- JavaScript : activé
- Accès aux fichiers : activé
- Téléchargements : activés
- Liens externes : activés
- Fenêtres popup : activées
- Lecture multimédia automatique : activée
- Stockage local : activé
- Orientation : portrait
- Icône : icons/icon-512.png

FICHIERS À IMPORTER
- index.html
- app.js
- style.css
- manifest.json
- logo-shortfactory.png
- icons/icon-192.png
- icons/icon-512.png
- README.txt
- GUIDE_CLES_API.txt

CLÉS API
Les clés ne sont pas intégrées dans l'APK.
Chaque utilisateur colle sa propre clé gratuite.
Elles sont enregistrées dans localStorage sur son appareil.
Il est possible de les effacer depuis l'application.

LIMITES TECHNIQUES
- Certaines URL vidéo peuvent refuser fetch() dans certaines WebView.
- Dans ce cas, télécharger le clip depuis sa page source puis l'importer.
- L'export se fait en temps réel : une vidéo de 30 secondes demande environ 30 secondes.
- Le format final dépend des codecs disponibles dans la WebView Android.
- Les recherches de stock ne peuvent pas représenter parfaitement une invention inexistante.
  Elles donnent surtout un rendu documentaire propre avec des images réelles.

MISE À JOUR
Pour installer cette version par-dessus une version précédente :
- conserver le même packageName ;
- utiliser la même clé de signature ;
- augmenter le versionCode.
