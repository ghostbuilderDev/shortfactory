SHORTFACTORY V6 PUTER — HTMLTOAPK

Cette version utilise Puter.js pour générer de vraies images IA.

FONCTIONNEMENT
1. Connexion Puter depuis l'application.
2. Saisie du sujet.
3. Création automatique de six scènes.
4. Création d'une fiche visuelle permanente.
5. Génération de six images avec puter.ai.txt2img().
6. Animation locale des images.
7. Sous-titres automatiques.
8. Ajout facultatif d'une narration ou d'une musique.
9. Export d'une vidéo verticale WebM de 30 secondes.

MODE TEST
Le mode test est activé par défaut.
Il permet de tester l'intégration sans utiliser de crédits.
Les images de test peuvent être des images exemples identiques ou génériques.
Désactiver le mode test pour demander une véritable génération IA.

AUTHENTIFICATION
La connexion Puter doit être déclenchée par le bouton visible dans l'application.
Dans HTMLtoAPK, les fenêtres popup et liens externes doivent être autorisés.
Si la fenêtre de connexion ne s'ouvre pas dans la WebView, l'authentification
devra être ouverte dans Chrome par le conteneur Android.

RÉGLAGES HTMLTOAPK
- fichier principal : index.html
- Internet : activé
- JavaScript : activé
- fenêtres popup : activées
- liens externes : activés
- accès aux fichiers : activé
- téléchargements : activés
- lecture multimédia : activée
- stockage local / cookies : activés
- orientation : portrait
- icône : icons/icon-512.png

FICHIERS
- index.html
- app.js
- style.css
- manifest.json
- logo-shortfactory.png
- icons/icon-192.png
- icons/icon-512.png
- README.txt

IMPORTANT
Puter utilise un modèle où l'utilisateur couvre sa propre consommation IA.
Il n'y a aucune clé API à intégrer dans l'APK.
L'application nécessite donc Internet et, pour les générations réelles,
un compte Puter autorisé à utiliser les services IA.

MISE À JOUR
Pour installer par-dessus une version précédente :
- même packageName ;
- même clé de signature ;
- versionCode supérieur.
