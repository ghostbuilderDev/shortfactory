SHORTFACTORY V4 IA — HTMLtoAPK

Cette version utilise de vrais générateurs vidéo IA distants hébergés dans des
Hugging Face Spaces. Le téléphone ne réalise pas le calcul GPU.

FONCTIONNEMENT
1. Saisir un sujet.
2. Optimiser le prompt.
3. Ajouter éventuellement un jeton Hugging Face en lecture seule.
4. Lancer Générer le clip IA.
5. Si l'API du Space a changé, utiliser le bouton Wan 2.1 Fast intégré.

RÉGLAGES HTMLtoAPK
- Fichier principal : index.html
- Internet : OBLIGATOIRE
- JavaScript : activé
- Liens externes : activés
- Téléchargements : activés
- Stockage local : activé
- Autoriser HTTP : inutile
- Orientation : portrait

LIMITES
- La disponibilité et les quotas dépendent de Hugging Face.
- Les propriétaires des Spaces peuvent modifier leurs endpoints.
- Le mode intégré est prévu comme secours.
- Le jeton est stocké dans localStorage sur l'appareil. Utiliser uniquement
  un jeton Hugging Face avec droits READ, jamais un jeton d'écriture.
- Gratuit ne signifie pas illimité : une file d'attente ou une limite
  quotidienne peut s'appliquer.

MOTEURS PAR DÉFAUT
- multimodalart/wan2-1-fast
- Wan-AI/Wan2.1

IMPORTANT
L'application n'intègre pas les poids du modèle. Elle est donc légère, mais
elle nécessite Internet et un Space disponible.
