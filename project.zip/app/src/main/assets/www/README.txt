SHORTFACTORY V3 — MOTEUR VIDÉO GÉNÉRATIF

Cette version ne repose pas sur des images fixes.
Elle génère chaque image de la vidéo en temps réel avec Canvas :

- routes et véhicules animés ;
- bâtiments et fenêtres dynamiques ;
- feu et boucliers de protection ;
- énergie, batteries et ondes ;
- réseaux technologiques ;
- eau et fluides ;
- animations abstraites ;
- mouvements de caméra ;
- transitions ;
- texte animé ;
- narration ou musique ;
- export vidéo WebM.

IMPORTANT
Ce moteur est un générateur vidéo procédural. Il ne produit pas des scènes
photoréalistes comme Sora, Veo ou Wan. Un modèle texte-vers-vidéo
photoréaliste ne peut pas raisonnablement être intégré dans une simple
application HTML-to-APK sans serveur ni plusieurs gigaoctets de modèles.

RÉGLAGES HTMLtoAPK
- Fichier principal : index.html
- JavaScript : activé
- Microphone : activé
- Téléchargements : activés
- Accès fichiers : activé
- Stockage local : activé
- Orientation : portrait
- Internet : facultatif

EXPORT
Le rendu est exporté en WebM. YouTube accepte ce format.
