SHORTFACTORY V4.2 — MULTI-MOTEURS

Moteurs : LTX 2.3 Turbo, LTX 2.3 Studio, LTX Video Fast, LTX 2.3 officiel.

Réglages HTMLtoAPK :
- fichier principal : index.html
- Internet : activé
- JavaScript : activé
- liens externes : activés
- téléchargements : activés
- presse-papiers : autorisé si disponible
- orientation : portrait

Premier test : 2 ou 3 secondes, format 16:9 si le vertical est refusé, mode rapide/distillé dans le moteur.
