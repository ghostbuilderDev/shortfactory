SHORTFACTORY V5 AGENT — HTMLTOAPK

OBJECTIF
Créer automatiquement une vidéo verticale de 30 secondes à partir d'un sujet.

FONCTIONS
- agent scénariste local ;
- six scènes automatiques de cinq secondes ;
- six prompts visuels cohérents ;
- génération de visuels procéduraux immédiatement fonctionnelle ;
- import d'une image pour chaque scène ;
- pont AndroidBridge prêt pour un futur moteur natif ;
- aperçu vidéo de 30 secondes ;
- enregistrement de narration ;
- import de musique ;
- synthèse vocale Android pour l'écoute ;
- sous-titres automatiques ;
- export WebM vertical 720 × 1280 ;
- diagnostic téléchargeable ;
- logo et icônes intégrés.

LIMITATION IMPORTANTE
Un dossier HTML seul ne peut pas embarquer MediaPipe Image Generator, NCNN,
Stable Diffusion ou Real-ESRGAN. Ces moteurs nécessitent des bibliothèques
Android natives. La V5 contient donc :
1. une version immédiatement fonctionnelle en HTML ;
2. un contrat AndroidBridge prêt à recevoir le moteur natif plus tard.

FICHIERS À IMPORTER DANS HTMLTOAPK
- index.html
- app.js
- style.css
- manifest.json
- logo-shortfactory.png
- dossier icons
- ANDROID_BRIDGE_SPEC.txt
- README.txt

RÉGLAGES HTMLTOAPK
- fichier principal : index.html
- JavaScript : activé
- microphone : activé
- accès aux fichiers : activé
- téléchargement : activé
- stockage local : activé
- lecture multimédia : activée
- orientation : portrait
- icône : icons/icon-512.png

MISE À JOUR
Pour installer par-dessus une version précédente :
- conserver le même packageName ;
- conserver la même clé de signature ;
- utiliser un versionCode supérieur.

PREMIER TEST
Sujet :
Une route capable de recharger les voitures électriques pendant qu'elles roulent

Puis :
1. Lancer l'agent IA.
2. Générer les six scènes.
3. Ajouter éventuellement des images.
4. Ajouter une narration ou une musique.
5. Générer la vidéo.
