SHORTFACTORY V4.1 — CORRECTION TEXTE VERS VIDÉO

CORRECTIONS PRINCIPALES
- suppression de l'import JavaScript externe @gradio/client ;
- aucun CDN requis pour faire fonctionner les boutons ;
- utilisation d'un véritable Space texte-vers-vidéo ;
- appel REST Gradio direct ;
- paramètres exacts du moteur LongCat Video ;
- suivi du flux Server-Sent Events ;
- diagnostic visible en cas d'erreur ;
- mode de secours ouvrant directement le moteur.

MOTEUR
multimodalart/LongCat-Video
https://multimodalart-longcat-video.hf.space

RÉGLAGES HTMLtoAPK
- Fichier principal : index.html
- Internet : activé
- JavaScript : activé
- Liens externes : activés
- Téléchargements : activés
- Stockage local : activé
- Orientation : portrait

TEST CONSEILLÉ
1. Installer l'APK.
2. Ouvrir Diagnostic technique.
3. Appuyer sur Tester le Space.
4. Vérifier le jeton.
5. Saisir une scène.
6. Choisir Mode rapide.
7. Optimiser le prompt.
8. Générer la vidéo IA.

LIMITES
- le Space et ZeroGPU peuvent être en file d'attente ;
- le compte gratuit dispose d'un quota GPU limité ;
- le mode haute qualité peut dépasser ce quota ;
- la disponibilité du Space dépend de Hugging Face ;
- une WebView qui bloque les requêtes CORS peut nécessiter le mode de secours.
