SHORTFACTORY V8 — CHATGPT COMPANION

Cette version utilise la génération d’images incluse dans ChatGPT, puis réalise localement une vidéo de 30 secondes.

IMPORTANT
L’abonnement ChatGPT ne fournit pas de crédits API utilisables automatiquement par une APK externe. Cette version fonctionne donc comme compagnon : elle prépare les prompts, ouvre ChatGPT, importe les images enregistrées, puis réalise le montage.

RÉGLAGES HTMLTOAPK
- fichier principal : index.html
- Internet : activé
- JavaScript : activé
- liens externes : activés
- fenêtres popup : activées
- partage Android / Web Share : activé si disponible
- accès aux fichiers : activé
- téléchargement : activé
- stockage local : activé
- lecture multimédia : activée
- orientation : portrait
- icône : icons/icon-512.png

PROCÉDURE
1. Préparer les six scènes.
2. Ouvrir une seule conversation ChatGPT.
3. Copier le prompt de la scène 1.
4. Générer puis enregistrer l’image.
5. Revenir dans ShortFactory et importer l’image.
6. Répéter jusqu’à 6/6.
7. Ajouter éventuellement un audio.
8. Générer la vidéo.
