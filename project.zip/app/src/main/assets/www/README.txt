SHORTFACTORY V4.4 — LOGO + BASCULE AUTOMATIQUE

NOUVEAUTÉS
- logo ShortFactory intégré dans l'application ;
- icônes Android 192 × 192 et 512 × 512 ;
- écran de démarrage avec logo ;
- vérification des moteurs avant ouverture ;
- détection après 45 secondes d'un Space bloqué sur Preparing Space ;
- proposition automatique :
  * ouvrir dans Chrome ;
  * passer au moteur suivant ;
- téléchargement d'un rapport diagnostic.

FICHIERS À IMPORTER DANS HTMLTOAPK
- index.html
- app.js
- style.css
- manifest.json
- logo-shortfactory.png
- dossier icons complet
- README.txt

RÉGLAGES HTMLTOAPK
- fichier principal : index.html
- Internet : activé
- JavaScript : activé
- liens externes : activés
- téléchargements : activés
- stockage local : activé
- presse-papiers : activé si disponible
- orientation : portrait
- icône : icons/icon-512.png

MISE À JOUR
Utiliser un versionCode supérieur à celui de la version installée.
Conserver exactement le même packageName pour installer la mise à jour par-dessus.
