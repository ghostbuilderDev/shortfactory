SHORTFACTORY MOBILE V2 — HTMLtoAPK

Cette version fonctionne sans serveur et sans clé API.

Fonctions :
- scénario local en 6 scènes ;
- visuels automatiques animés ;
- ajout d'une image par scène ;
- aperçu vertical ;
- ajout d'une musique ou d'une narration ;
- enregistrement au microphone ;
- export vidéo WebM directement sur le téléphone.

IMPORTANT
Cette version ne contient pas encore un modèle de diffusion photoréaliste. Elle crée une vraie vidéo animée à partir de visuels automatiques ou des images choisies dans la galerie.

CONFIGURATION HTMLtoAPK
- Fichier de démarrage : index.html
- JavaScript : activé
- Stockage local : activé
- Accès aux fichiers : activé
- Microphone : autorisé
- Téléchargements : autorisés
- Orientation : portrait
- Internet : non obligatoire

Le moteur d'export utilise MediaRecorder et canvas.captureStream. Si la WebView de HTMLtoAPK ne les autorise pas, teste d'abord index.html dans Chrome Android.
