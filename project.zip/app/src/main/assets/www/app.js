import { Client } from "https://cdn.jsdelivr.net/npm/@gradio/client/dist/index.min.js";

const $=s=>document.querySelector(s);
let activeJob=null;
const toast=t=>{const e=$("#toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),2600)};
const log=t=>{$("#log").textContent+=`[${new Date().toLocaleTimeString("fr-FR")}] ${t}\n`;$("#log").scrollTop=$("#log").scrollHeight};
const setProgress=n=>$("#bar").style.width=Math.max(0,Math.min(100,n))+"%";

function saveSettings(){
 localStorage.setItem("sf4_token",$("#hfToken").value.trim());
 localStorage.setItem("sf4_space",$("#spaceId").value.trim());
 localStorage.setItem("sf4_api",$("#apiName").value.trim());
 toast("Réglages enregistrés.");
}
function loadSettings(){
 $("#hfToken").value=localStorage.getItem("sf4_token")||"";
 $("#spaceId").value=localStorage.getItem("sf4_space")||"multimodalart/wan2-1-fast";
 $("#apiName").value=localStorage.getItem("sf4_api")||"/generate";
}
$("#saveToken").onclick=saveSettings;
$("#showToken").onclick=()=>{$("#hfToken").type=$("#hfToken").type==="password"?"text":"password"};
window.addEventListener("online",updateNetwork);window.addEventListener("offline",updateNetwork);
function updateNetwork(){const ok=navigator.onLine;$("#netBadge").textContent=ok?"Internet disponible":"Hors connexion";$("#netBadge").classList.toggle("ok",ok)}
updateNetwork();loadSettings();

function styleText(v){
 return {
  cinematic:"cinematic photorealistic film, natural lighting, realistic materials, detailed environment, shallow depth of field",
  documentary:"premium documentary footage, realistic natural light, physically accurate motion, authentic environment",
  futuristic:"photorealistic near-future science fiction, believable technology, cinematic light, high detail",
  advertising:"premium commercial film, elegant composition, polished realistic lighting, luxury advertising quality",
  drone:"spectacular aerial drone shot, realistic scale, smooth motion, cinematic landscape"
 }[v]||"cinematic photorealistic film";
}
$("#buildPrompt").onclick=()=>{
 const s=$("#subject").value.trim();if(s.length<8){toast("Entre un sujet plus précis.");return}
 const ratio=$("#ratio").value;
 $("#prompt").value=`${s}. ${styleText($("#style").value)}. ${$("#camera").value}, smooth physically plausible movement, coherent objects, consistent geometry, rich details, natural colors, professional color grading, ${ratio} composition, no visible text, one continuous shot.`;
 $("#negativePrompt").value=$("#negative").value.trim();
 $("#promptCard").classList.remove("hidden");$("#promptCard").scrollIntoView({behavior:"smooth"});toast("Prompt optimisé.");
};

async function connectSpace(){
 const token=$("#hfToken").value.trim();
 const id=$("#spaceId").value.trim();
 log(`Connexion à ${id}…`);
 return await Client.connect(id,token?{token}:{});
}
async function getApiInfo(client){
 try{
  if(typeof client.view_api==="function") return await client.view_api();
 }catch(e){}
 try{return client.config||client.api_info||null}catch(e){return null}
}
$("#inspectApi").onclick=async()=>{
 $("#apiInfo").textContent="Connexion…";
 try{
  const c=await connectSpace(),info=await getApiInfo(c);
  $("#apiInfo").textContent=JSON.stringify(info,null,2)||"Informations indisponibles. Utilise le mode intégré.";
 }catch(e){$("#apiInfo").textContent=String(e?.message||e)}
};
$("#testEngine").onclick=async()=>{
 $("#jobCard").classList.remove("hidden");$("#log").textContent="";setProgress(8);
 try{
  const c=await connectSpace();setProgress(100);log("Connexion réussie.");const info=await getApiInfo(c);if(info)log("API détectée.");toast("Moteur accessible.");
 }catch(e){setProgress(0);log("Échec : "+(e?.message||e));toast("Moteur indisponible ou quota épuisé.");}
};

function parseCustomArgs(){
 const v=$("#customArgs").value.trim();if(!v)return null;
 const x=JSON.parse(v);return Array.isArray(x)?x:[x];
}
function candidatePayloads(prompt,negative){
 const q=$("#quality").value,ratio=$("#ratio").value;
 const size=ratio==="9:16"?"480*832":ratio==="16:9"?"832*480":"640*640";
 const steps=q==="fast"?4:q==="quality"?8:6;
 return [
  [prompt,negative,0,true,steps],
  [prompt,negative,steps,0],
  [prompt,negative],
  [prompt,size,steps,0],
  [prompt],
  {prompt,negative_prompt:negative,num_inference_steps:steps,seed:0,width:ratio==="9:16"?480:832,height:ratio==="9:16"?832:480}
 ];
}
function apiCandidates(){
 const manual=$("#apiName").value.trim();
 return [...new Set([manual,"/generate","/generate_video","/infer","/predict","/run"].filter(Boolean))];
}
function findVideo(value){
 if(!value)return null;
 if(typeof value==="string"&&(/\.(mp4|webm|mov)(\?|$)/i.test(value)||value.startsWith("http")))return value;
 if(Array.isArray(value)){for(const x of value){const r=findVideo(x);if(r)return r}}
 if(typeof value==="object"){
  for(const k of ["url","path","video","value","name"]){if(value[k]){const r=findVideo(value[k]);if(r)return r}}
  for(const x of Object.values(value)){const r=findVideo(x);if(r)return r}
 }
 return null;
}
async function runAttempt(client,api,args){
 log(`Essai ${api} avec ${Array.isArray(args)?args.length:"objet"} argument(s)…`);
 const job=client.submit(api,args);activeJob=job;let result=null,progress=15;
 for await(const msg of job){
  if(msg.type==="status"){
   if(msg.position!=null)log(`File d’attente : position ${msg.position}`);
   if(msg.eta!=null)log(`Temps estimé : ${Math.round(msg.eta)} s`);
   progress=Math.min(88,progress+4);setProgress(progress);
  }
  if(msg.type==="data"){result=msg.data;log("Réponse intermédiaire reçue.");}
 }
 if(!result&&job.result)result=await job.result();
 return result;
}
$("#generateBtn").onclick=async()=>{
 if(!navigator.onLine){toast("Connexion Internet nécessaire.");return}
 const prompt=$("#prompt").value.trim(),negative=$("#negativePrompt").value.trim();if(!prompt){toast("Prompt vide.");return}
 $("#jobCard").classList.remove("hidden");$("#resultCard").classList.add("hidden");$("#log").textContent="";$("#jobState").textContent="Connexion au moteur…";setProgress(5);$("#generateBtn").disabled=true;$("#cancelBtn").classList.remove("hidden");
 try{
  saveSettings();const client=await connectSpace();setProgress(12);$("#jobState").textContent="Recherche de la bonne API…";
  const custom=parseCustomArgs(),payloads=custom?[custom]:candidatePayloads(prompt,negative),apis=apiCandidates();
  let final=null,lastError=null;
  outer:for(const api of apis){
   for(const payload of payloads){
    try{final=await runAttempt(client,api,payload);const url=findVideo(final);if(url){showResult(url);break outer}}
    catch(e){lastError=e;log(`Refus de ${api} : ${e?.message||e}`)}
   }
  }
  if(!$("#resultCard").classList.contains("hidden"))return;
  throw lastError||new Error("Aucun fichier vidéo trouvé dans la réponse.");
 }catch(e){
  setProgress(0);$("#jobState").textContent="La génération directe a échoué.";log("Erreur finale : "+(e?.message||e));log("Utilise « Ouvrir Wan 2.1 Fast » ci-dessous : ce mode reste fonctionnel même si l’API du Space change.");toast("API incompatible ou quota indisponible.");
 }finally{$("#generateBtn").disabled=false;$("#cancelBtn").classList.add("hidden");activeJob=null}
};
function showResult(url){
 setProgress(100);$("#jobState").textContent="Vidéo terminée.";$("#video").src=url;$("#download").href=url;$("#resultCard").classList.remove("hidden");$("#resultCard").scrollIntoView({behavior:"smooth"});toast("Clip IA terminé.");
}
$("#cancelBtn").onclick=()=>{try{activeJob?.cancel?.();log("Annulation demandée.");}catch(e){}};
function openSpace(url,title){$("#modalTitle").textContent=title;$("#spaceFrame").src=url;$("#modal").classList.remove("hidden")}
$("#openWanFast").onclick=()=>openSpace("https://multimodalart-wan2-1-fast.hf.space","Wan 2.1 Fast");
$("#openWanOfficial").onclick=()=>openSpace("https://wan-ai-wan2-1.hf.space","Wan 2.1 officiel");
$("#closeModal").onclick=()=>{$("#spaceFrame").src="about:blank";$("#modal").classList.add("hidden")};
