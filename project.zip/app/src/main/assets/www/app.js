
(function(){
"use strict";

const SPACE_BASE = "https://multimodalart-longcat-video.hf.space";
const API_NAME = "generate_video";

const $ = s => document.querySelector(s);
let currentController = null;

function toast(message){
  const el = $("#toast");
  el.textContent = message;
  el.classList.add("show");
  setTimeout(()=>el.classList.remove("show"),2600);
}

function appendLog(message, target="#log"){
  const el = $(target);
  if(!el) return;
  el.textContent += `[${new Date().toLocaleTimeString("fr-FR")}] ${message}\n`;
  el.scrollTop = el.scrollHeight;
}

function setProgress(value){
  $("#bar").style.width = Math.max(0,Math.min(100,value))+"%";
}

function showFatal(message){
  const el=$("#fatalBanner");
  el.textContent=message;
  el.classList.remove("hidden");
}

window.addEventListener("error",e=>{
  showFatal("Erreur JavaScript : "+(e.message||"erreur inconnue"));
  appendLog("Erreur globale : "+(e.message||e), "#diagnostic");
});
window.addEventListener("unhandledrejection",e=>{
  const msg=e.reason?.message||String(e.reason||"promesse rejetée");
  showFatal("Erreur réseau ou JavaScript : "+msg);
  appendLog("Promesse rejetée : "+msg, "#diagnostic");
});

function updateNetwork(){
  const online=navigator.onLine;
  $("#netBadge").textContent=online?"Internet disponible":"Hors connexion";
  $("#netBadge").classList.toggle("ok",online);
}
window.addEventListener("online",updateNetwork);
window.addEventListener("offline",updateNetwork);
updateNetwork();

function loadToken(){
  $("#hfToken").value=localStorage.getItem("sf41_hf_token")||"";
}
function saveToken(){
  const token=$("#hfToken").value.trim();
  if(token && !token.startsWith("hf_")){
    toast("Le jeton doit commencer par hf_.");
    return;
  }
  localStorage.setItem("sf41_hf_token",token);
  $("#tokenStatus").textContent=token?"Jeton enregistré localement.":"Jeton supprimé.";
  toast("Jeton enregistré.");
}
loadToken();

$("#showToken").addEventListener("click",()=>{
  $("#hfToken").type=$("#hfToken").type==="password"?"text":"password";
});
$("#saveToken").addEventListener("click",saveToken);

async function verifyToken(){
  const token=$("#hfToken").value.trim();
  const status=$("#tokenStatus");
  if(!token){
    status.textContent="Aucun jeton saisi. Le mode anonyme reste possible.";
    status.className="statusLine";
    return;
  }
  status.textContent="Vérification…";
  status.className="statusLine";
  try{
    const res=await fetch("https://huggingface.co/api/whoami-v2",{
      headers:{Authorization:`Bearer ${token}`}
    });
    if(!res.ok) throw new Error(`HTTP ${res.status}`);
    const data=await res.json();
    status.textContent=`Jeton valide — compte : ${data.name||data.fullname||"Hugging Face"}`;
    status.className="statusLine ok";
    localStorage.setItem("sf41_hf_token",token);
  }catch(err){
    status.textContent="Impossible de vérifier le jeton : "+err.message;
    status.className="statusLine bad";
  }
}
$("#verifyToken").addEventListener("click",verifyToken);

const styles={
  cinematic:"cinematic photorealistic film, natural lighting, realistic materials, detailed environment, professional color grading",
  documentary:"premium documentary footage, physically accurate motion, authentic natural lighting, realistic environment",
  future:"photorealistic near-future science fiction, believable technology, cinematic lighting, consistent geometry",
  advert:"premium commercial film, luxury advertising quality, elegant lighting, polished realistic details",
  drone:"spectacular aerial cinematography, realistic scale, smooth drone movement, detailed landscape"
};

function getDimensions(){
  const ratio=$("#ratio").value;
  if(ratio==="9:16") return {height:832,width:480,label:"480 × 832"};
  if(ratio==="16:9") return {height:480,width:832,label:"832 × 480"};
  return {height:640,width:640,label:"640 × 640"};
}

$("#ratio").addEventListener("change",()=>{
  $("#resolutionView").value=getDimensions().label;
});

$("#optimizeBtn").addEventListener("click",()=>{
  const subject=$("#subject").value.trim();
  if(subject.length<10){
    toast("Décris la scène plus précisément.");
    return;
  }
  const ratio=$("#ratio").value;
  const prompt=[
    subject,
    styles[$("#style").value],
    $("#camera").value,
    "smooth physically plausible movement",
    "coherent objects and consistent geometry",
    "rich fine details",
    "natural motion blur",
    "no visible text",
    `composition optimized for ${ratio}`,
    "one continuous six-second shot"
  ].join(", ")+".";
  $("#prompt").value=prompt;
  $("#resolutionView").value=getDimensions().label;
  $("#promptCard").classList.remove("hidden");
  $("#promptCard").scrollIntoView({behavior:"smooth"});
  toast("Prompt optimisé.");
});

function headers(){
  const token=$("#hfToken").value.trim();
  const h={"Content-Type":"application/json"};
  if(token) h.Authorization=`Bearer ${token}`;
  return h;
}

function parseEventBlock(block){
  let event="",data="";
  for(const line of block.split(/\r?\n/)){
    if(line.startsWith("event:")) event=line.slice(6).trim();
    if(line.startsWith("data:")) data+=line.slice(5).trim();
  }
  return {event,data};
}

function findVideoUrl(value){
  if(!value) return null;
  if(typeof value==="string"){
    if(/^https?:\/\//i.test(value)) return value;
    if(/\.(mp4|webm|mov)$/i.test(value)){
      return `${SPACE_BASE}/gradio_api/file=${encodeURIComponent(value)}`;
    }
    return null;
  }
  if(Array.isArray(value)){
    for(const item of value){
      const found=findVideoUrl(item);
      if(found) return found;
    }
  }
  if(typeof value==="object"){
    if(typeof value.url==="string") return value.url;
    if(typeof value.path==="string"){
      if(/^https?:\/\//i.test(value.path)) return value.path;
      return `${SPACE_BASE}/gradio_api/file=${encodeURIComponent(value.path)}`;
    }
    for(const item of Object.values(value)){
      const found=findVideoUrl(item);
      if(found) return found;
    }
  }
  return null;
}

async function submitGeneration(){
  const prompt=$("#prompt").value.trim();
  if(!prompt){
    toast("Le prompt est vide.");
    return;
  }
  if(!navigator.onLine){
    toast("Connexion Internet nécessaire.");
    return;
  }

  const dimensions=getDimensions();
  const quality=$("#quality").value;
  const useDistill=quality==="fast" || quality==="refine";
  const useRefine=quality==="refine";
  const seed=Math.max(0,Number($("#seed").value)||42);
  const negative=$("#negative").value.trim();

  const payload={
    data:[
      "t2v",
      prompt,
      negative,
      null,
      dimensions.height,
      dimensions.width,
      null,
      seed,
      useDistill,
      useRefine
    ]
  };

  $("#jobCard").classList.remove("hidden");
  $("#resultCard").classList.add("hidden");
  $("#log").textContent="";
  $("#jobState").textContent="Envoi au moteur LongCat Video…";
  $("#generateBtn").disabled=true;
  $("#cancelBtn").classList.remove("hidden");
  setProgress(5);

  currentController=new AbortController();

  try{
    appendLog("Moteur : multimodalart/LongCat-Video");
    appendLog(`Résolution : ${dimensions.label}`);
    appendLog(`Mode : ${quality}`);
    appendLog("Envoi de la demande…");

    const submit=await fetch(`${SPACE_BASE}/gradio_api/call/${API_NAME}`,{
      method:"POST",
      headers:headers(),
      body:JSON.stringify(payload),
      signal:currentController.signal
    });

    if(!submit.ok){
      const body=await submit.text().catch(()=>"");
      throw new Error(`Envoi refusé HTTP ${submit.status} ${body.slice(0,180)}`);
    }

    const submitted=await submit.json();
    if(!submitted.event_id) throw new Error("Le moteur n’a pas renvoyé d’identifiant de tâche.");

    appendLog("Tâche acceptée : "+submitted.event_id);
    $("#jobState").textContent="Dans la file d’attente GPU…";
    setProgress(12);

    const stream=await fetch(
      `${SPACE_BASE}/gradio_api/call/${API_NAME}/${encodeURIComponent(submitted.event_id)}`,
      {headers:headers(),signal:currentController.signal}
    );

    if(!stream.ok) throw new Error(`Lecture du résultat refusée HTTP ${stream.status}`);
    if(!stream.body) throw new Error("Le navigateur ne permet pas la lecture du flux de progression.");

    const reader=stream.body.getReader();
    const decoder=new TextDecoder();
    let buffer="";
    let progress=14;
    let finished=false;

    while(true){
      const {done,value}=await reader.read();
      if(done) break;
      buffer+=decoder.decode(value,{stream:true});
      const blocks=buffer.split(/\n\n/);
      buffer=blocks.pop()||"";

      for(const block of blocks){
        const evt=parseEventBlock(block);
        if(!evt.event && !evt.data) continue;

        if(evt.event==="heartbeat") continue;

        if(evt.event==="generating" || evt.event==="pending"){
          progress=Math.min(88,progress+3);
          setProgress(progress);
          $("#jobState").textContent=evt.event==="pending"?"En attente d’un GPU…":"Le GPU génère la vidéo…";
          appendLog(evt.event==="pending"?"Toujours dans la file d’attente.":"Génération en cours…");
        }

        if(evt.event==="error"){
          throw new Error(evt.data||"Erreur retournée par le moteur.");
        }

        if(evt.event==="complete"){
          let data;
          try{data=JSON.parse(evt.data)}catch{data=evt.data}
          const url=findVideoUrl(data);
          if(!url){
            appendLog("Réponse complète : "+JSON.stringify(data).slice(0,900));
            throw new Error("Vidéo terminée, mais l’adresse du fichier n’a pas été reconnue.");
          }
          showResult(url);
          finished=true;
          break;
        }
      }
      if(finished) break;
    }

    if(!finished) throw new Error("Le flux s’est terminé sans résultat vidéo.");

  }catch(err){
    if(err.name==="AbortError"){
      $("#jobState").textContent="Génération annulée.";
      appendLog("Annulation effectuée.");
    }else{
      setProgress(0);
      $("#jobState").textContent="Échec de la génération.";
      appendLog("ERREUR : "+err.message);
      appendLog("Utilise le mode de secours pour vérifier le moteur directement.");
      toast("Échec : consulte le journal.");
    }
  }finally{
    currentController=null;
    $("#generateBtn").disabled=false;
    $("#cancelBtn").classList.add("hidden");
  }
}

function showResult(url){
  setProgress(100);
  $("#jobState").textContent="Vidéo terminée.";
  $("#video").src=url;
  $("#downloadBtn").href=url;
  $("#resultCard").classList.remove("hidden");
  $("#resultCard").scrollIntoView({behavior:"smooth"});
  appendLog("Vidéo reçue.");
  toast("Clip IA terminé.");
}

$("#generateBtn").addEventListener("click",submitGeneration);

$("#cancelBtn").addEventListener("click",()=>{
  if(currentController) currentController.abort();
});

async function testSpace(){
  $("#diagnostic").textContent="";
  appendLog("Test du Space…","#diagnostic");
  try{
    const res=await fetch(`${SPACE_BASE}/gradio_api/openapi.json`,{
      headers:headers()
    });
    appendLog(`OpenAPI HTTP ${res.status}`,"#diagnostic");
    const text=await res.text();
    appendLog(text.slice(0,1400),"#diagnostic");
    if(!res.ok) throw new Error(`HTTP ${res.status}`);
    toast("Space accessible.");
  }catch(err){
    appendLog("Erreur : "+err.message,"#diagnostic");
    toast("Space inaccessible depuis la WebView.");
  }
}
$("#testSpaceBtn").addEventListener("click",testSpace);
$("#clearLogBtn").addEventListener("click",()=>{$("#diagnostic").textContent=""});

$("#copyOpenBtn").addEventListener("click",async()=>{
  const prompt=$("#prompt").value.trim()||$("#subject").value.trim();
  try{
    if(prompt && navigator.clipboard) await navigator.clipboard.writeText(prompt);
    toast(prompt?"Prompt copié.":"Ouverture du moteur.");
  }catch{}
  window.open(`${SPACE_BASE}/?__theme=dark`,"_blank");
});

$("#resolutionView").value=getDimensions().label;
appendLog("JavaScript local chargé correctement.","#diagnostic");

})();
