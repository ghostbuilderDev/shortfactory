
(function(){
"use strict";

const $=s=>document.querySelector(s);
const canvas=$("#canvas"),ctx=canvas.getContext("2d");
let scenes=[],sceneImages=[],audioBlob=null,audioUrl=null,mediaRecorder=null,audioChunks=[],previewHandle=null;
const DURATION=30,SCENE_DURATION=5;

const toast=t=>{const x=$("#toast");x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),2500)};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const hash=s=>{let h=0;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))|0;return Math.abs(h)};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));

setTimeout(()=>$("#splash").classList.add("hide"),1500);

function hasBridge(){
 return !!(window.AndroidBridge && typeof window.AndroidBridge.generateImage==="function");
}
function bridgeName(){
 if(hasBridge()) return "AndroidBridge natif disponible";
 return "Moteur HTML autonome";
}
$("#bridgeValue").textContent=bridgeName();
$("#engineBadge").textContent=hasBridge()?"Moteur natif":"Mode autonome";

function styleText(){
 return {
  cinematic:"cinematic photorealistic, realistic materials, natural lighting, professional color grading",
  documentary:"premium documentary footage, authentic environment, realistic natural light",
  future:"photorealistic near-future technology, coherent geometry, cinematic light",
  premium:"premium commercial film, elegant composition, polished realistic details",
  technical:"clean technical visualization, realistic objects, clear educational composition"
 }[$("#style").value];
}

function createPlan(subject,cta){
 const base=subject.trim();
 return[
  {title:"Accroche",narration:`Et si ${base.toLowerCase()} pouvait changer notre quotidien ?`,visual:`A spectacular opening shot introducing ${base}. ${styleText()}, strong visual hook, smooth forward camera movement.`},
  {title:"Le problème",narration:`Aujourd’hui, cette idée répond à un problème concret que beaucoup de personnes rencontrent.`,visual:`A realistic scene showing the practical problem before ${base} is adopted. Clear visual storytelling, coherent environment.`},
  {title:"Le fonctionnement",narration:`Le principe est simple : le système analyse la situation et agit automatiquement en temps réel.`,visual:`Detailed cinematic demonstration of how ${base} works, visible technology, energy flow, believable mechanics.`},
  {title:"Les avantages",narration:`Le résultat pourrait faire gagner du temps, réduire les coûts et améliorer la sécurité.`,visual:`Positive real-world benefits of ${base}, efficient movement, safer environment, premium documentary style.`},
  {title:"Les limites",narration:`Mais il faut encore vérifier son prix, sa fiabilité et son impact réel avant de l’adopter.`,visual:`Balanced realistic scene revealing limits and practical challenges of ${base}, thoughtful cinematic mood.`},
  {title:"Conclusion",narration:cta,visual:`Epic concluding shot of ${base} succeeding in a believable future, smooth camera rise, memorable final composition.`}
 ].map((s,i)=>({...s,seed:42+i,type:detectType(base+" "+s.visual)}));
}

function detectType(t){
 t=t.toLowerCase();
 if(/route|voiture|véhicule|transport|train|mobilité/.test(t))return"transport";
 if(/maison|bâtiment|chantier|béton|construction/.test(t))return"building";
 if(/feu|incendie|flamme|chaleur/.test(t))return"fire";
 if(/énergie|électricité|batterie|recharge|solaire/.test(t))return"energy";
 if(/eau|mer|océan|pluie|hydrogène/.test(t))return"water";
 return"technology";
}

$("#agentBtn").onclick=async()=>{
 const subject=$("#subject").value.trim();
 if(subject.length<5){toast("Entre un sujet précis.");return}
 $("#planCard").classList.remove("hidden");
 $("#agentBar").style.width="8%";$("#agentState").textContent="Analyse du sujet…";
 await sleep(350);
 $("#agentBar").style.width="30%";$("#agentState").textContent="Construction de l’accroche…";
 await sleep(350);
 $("#agentBar").style.width="55%";$("#agentState").textContent="Découpage en six scènes…";
 scenes=createPlan(subject,$("#cta").value.trim());
 sceneImages=new Array(6).fill(null);
 await sleep(350);
 $("#agentBar").style.width="82%";$("#agentState").textContent="Création des prompts cohérents…";
 renderScenes();
 await sleep(350);
 $("#agentBar").style.width="100%";$("#agentState").textContent="Plan de 30 secondes terminé.";
 $("#visualCard").classList.remove("hidden");$("#audioCard").classList.remove("hidden");$("#renderCard").classList.remove("hidden");
 drawFrame(0,0);
 $("#planCard").scrollIntoView({behavior:"smooth"});
};

function renderScenes(){
 $("#sceneList").innerHTML=scenes.map((s,i)=>`
 <div class="scene">
   <div class="sceneHead"><b>Scène ${i+1} — ${s.title}</b><span>5 secondes</span></div>
   <label>Narration<textarea data-narration="${i}">${escapeHtml(s.narration)}</textarea></label>
   <label>Prompt visuel<textarea data-visual="${i}">${escapeHtml(s.visual)}</textarea></label>
   <canvas class="visual" id="visual${i}" width="540" height="960"></canvas>
   <div class="sceneActions">
     <button class="secondary regen" data-regenerate="${i}">Régénérer</button>
     <label class="secondary" style="display:grid;place-items:center;margin:0">
       Importer une image<input class="hidden sceneImport" data-import="${i}" type="file" accept="image/*">
     </label>
   </div>
 </div>`).join("");
 document.querySelectorAll("[data-narration]").forEach(el=>el.oninput=e=>scenes[+e.target.dataset.narration].narration=e.target.value);
 document.querySelectorAll("[data-visual]").forEach(el=>el.oninput=e=>scenes[+e.target.dataset.visual].visual=e.target.value);
 document.querySelectorAll("[data-regenerate]").forEach(el=>el.onclick=()=>generateScene(+el.dataset.regenerate));
 document.querySelectorAll("[data-import]").forEach(el=>el.onchange=e=>importSceneFile(+el.dataset.import,e.target.files[0]));
 scenes.forEach((_,i)=>drawScenePreview(i));
}

function escapeHtml(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

async function generateScene(i){
 const s=scenes[i];
 if(hasBridge()){
  try{
   toast(`Génération native de la scène ${i+1}…`);
   const result=window.AndroidBridge.generateImage(JSON.stringify({
    prompt:s.visual,
    negativePrompt:"blurry, distortion, duplicated objects, text, logo, watermark",
    width:512,height:896,seed:s.seed,style:$("#style").value
   }));
   if(result){
    await loadBridgeImage(i,result);
    toast(`Scène ${i+1} générée.`);
    return;
   }
  }catch(err){
   console.warn("AndroidBridge error",err);
  }
 }
 sceneImages[i]=null;
 drawScenePreview(i);
 toast(`Scène ${i+1} créée par le moteur autonome.`);
}

async function loadBridgeImage(i,value){
 return new Promise((resolve,reject)=>{
  const img=new Image();
  img.onload=()=>{sceneImages[i]=img;drawScenePreview(i);resolve()};
  img.onerror=reject;
  img.src=value.startsWith("data:")||value.startsWith("file:")||value.startsWith("http")?value:`data:image/png;base64,${value}`;
 });
}

async function importSceneFile(i,file){
 if(!file)return;
 const url=URL.createObjectURL(file),img=new Image();
 img.onload=()=>{sceneImages[i]=img;drawScenePreview(i);URL.revokeObjectURL(url);toast(`Image ajoutée à la scène ${i+1}.`)};
 img.src=url;
}

$("#generateAllBtn").onclick=async()=>{
 $("#generateAllBtn").disabled=true;
 for(let i=0;i<6;i++){
  $("#agentState").textContent=`Génération de la scène ${i+1}/6…`;
  $("#agentBar").style.width=((i+1)/6*100)+"%";
  await generateScene(i);
  await sleep(180);
 }
 $("#agentState").textContent="Les six scènes sont prêtes.";
 $("#generateAllBtn").disabled=false;
};

$("#importBtn").onclick=()=>$("#multiImport").click();
$("#multiImport").onchange=e=>{
 const files=[...e.target.files].slice(0,6);
 files.forEach((f,i)=>importSceneFile(i,f));
};

function drawScenePreview(i){
 const c=$("#visual"+i);if(!c)return;
 const g=c.getContext("2d");
 drawGeneratedVisual(g,c.width,c.height,scenes[i],0.25,sceneImages[i]);
}

function drawGeneratedVisual(g,w,h,s,t,img){
 if(img){
  g.fillStyle="#000";g.fillRect(0,0,w,h);
  const ir=img.width/img.height,cr=w/h;let dw,dh;
  if(ir>cr){dh=h*1.08;dw=dh*ir}else{dw=w*1.08;dh=dw/ir}
  g.drawImage(img,(w-dw)/2+(t-.5)*25,(h-dh)/2,dw,dh);
  g.fillStyle="rgba(0,0,0,.22)";g.fillRect(0,0,w,h);
 }else{
  const seed=s.seed||42,hue=seed*47%360;
  const grad=g.createLinearGradient(0,0,w,h);
  grad.addColorStop(0,`hsl(${hue} 55% 20%)`);
  grad.addColorStop(1,`hsl(${(hue+70)%360} 68% 7%)`);
  g.fillStyle=grad;g.fillRect(0,0,w,h);
  for(let k=0;k<25;k++){
   const x=(seed*(k+5)*19+t*70*(k%4+1))%(w+100)-50;
   const y=(seed*(k+9)*13+t*45*(k%3+1))%(h+100)-50;
   g.beginPath();g.arc(x,y,4+(k%5)*4,0,Math.PI*2);
   g.fillStyle=`hsla(${(hue+k*19)%360},85%,65%,${.05+(k%4)*.03})`;g.fill();
  }
  if(s.type==="transport")drawRoad(g,w,h,t);
  else if(s.type==="building")drawBuilding(g,w,h,t);
  else if(s.type==="fire")drawFire(g,w,h,t);
  else if(s.type==="energy")drawEnergy(g,w,h,t);
  else if(s.type==="water")drawWater(g,w,h,t);
  else drawTechnology(g,w,h,t);
 }
}

function drawRoad(g,w,h,t){
 g.fillStyle="#101723";g.beginPath();g.moveTo(w*.12,h);g.lineTo(w*.41,h*.42);g.lineTo(w*.59,h*.42);g.lineTo(w*.9,h);g.closePath();g.fill();
 g.strokeStyle="rgba(70,210,255,.9)";g.lineWidth=8;g.setLineDash([38,25]);g.lineDashOffset=-t*150;g.beginPath();g.moveTo(w*.5,h);g.lineTo(w*.5,h*.44);g.stroke();g.setLineDash([]);
 const x=w*.5,y=h*.66;g.fillStyle="#090d16";round(g,x-90,y-30,180,65,20);g.fill();g.fillStyle="#51d8ff";round(g,x-60,y-55,120,35,14);g.fill();
}
function drawBuilding(g,w,h,t){
 g.fillStyle="#10182a";g.fillRect(w*.12,h*.3,w*.76,h*.62);
 for(let r=0;r<6;r++)for(let c=0;c<4;c++){g.fillStyle=`rgba(70,210,255,${.25+.6*Math.max(0,Math.sin(t*5+r+c))})`;g.fillRect(w*.2+c*w*.16,h*.37+r*h*.075,w*.07,h*.045)}
}
function drawFire(g,w,h,t){
 for(let i=0;i<18;i++){const x=w*.2+(i*43%(w*.6)),y=h*.78-(i%5)*30-Math.sin(t*8+i)*25;g.beginPath();g.arc(x,y,35+(i%4)*10,0,Math.PI*2);g.fillStyle=`hsla(${15+i%3*18},95%,55%,.38)`;g.fill()}
}
function drawEnergy(g,w,h,t){
 for(let i=0;i<7;i++){g.strokeStyle=`rgba(65,215,255,${.2+i*.08})`;g.lineWidth=5;g.beginPath();for(let x=0;x<w;x+=14)g.lineTo(x,h*.52+i*27+Math.sin(x*.035+t*5+i)*15);g.stroke()}
}
function drawWater(g,w,h,t){
 g.fillStyle="rgba(25,120,190,.3)";g.fillRect(0,h*.48,w,h*.52);for(let i=0;i<8;i++){g.strokeStyle=`rgba(70,210,255,${.18+i*.04})`;g.lineWidth=4;g.beginPath();for(let x=0;x<w;x+=14)g.lineTo(x,h*.55+i*42+Math.sin(x*.035+t*4+i)*14);g.stroke()}
}
function drawTechnology(g,w,h,t){
 const nodes=[];for(let i=0;i<16;i++){const a=i/16*Math.PI*2+t*.3,r=70+(i%4)*45;nodes.push([w*.5+Math.cos(a)*r,h*.58+Math.sin(a)*r])}
 g.strokeStyle="rgba(100,190,255,.3)";for(let i=0;i<nodes.length;i++)for(let j=i+1;j<nodes.length;j++)if((i+j)%5===0){g.beginPath();g.moveTo(...nodes[i]);g.lineTo(...nodes[j]);g.stroke()}
 nodes.forEach((n,i)=>{g.beginPath();g.arc(n[0],n[1],7+(i%3)*3,0,7);g.fillStyle=i%2?"#45d6ff":"#9b73ff";g.fill()});
}
function round(g,x,y,w,h,r){g.beginPath();g.moveTo(x+r,y);g.arcTo(x+w,y,x+w,y+h,r);g.arcTo(x+w,y+h,x,y+h,r);g.arcTo(x,y+h,x,y,r);g.arcTo(x,y,x+w,y,r);g.closePath()}

function splitLines(text,max=27){
 const words=text.split(/\s+/),out=[];let line="";
 for(const word of words){const test=(line+" "+word).trim();if(test.length>max&&line){out.push(line);line=word}else line=test}
 if(line)out.push(line);return out.slice(0,7);
}

function drawFrame(index,localT){
 const s=scenes[index]||{narration:"ShortFactory V5",seed:42,type:"technology"};
 drawGeneratedVisual(ctx,canvas.width,canvas.height,s,localT,sceneImages[index]);
 const fade=clamp(Math.min(localT*5,(1-localT)*5),0,1);
 ctx.globalAlpha=fade;
 ctx.fillStyle="rgba(0,0,0,.48)";round(ctx,48,145,624,930,36);ctx.fill();
 ctx.fillStyle="#fff";ctx.textAlign="center";ctx.textBaseline="middle";ctx.font="700 47px system-ui";
 const ls=splitLines(s.narration),lh=65,total=ls.length*lh;
 ls.forEach((line,i)=>ctx.fillText(line,360,620-total/2+i*lh+lh/2,565));
 ctx.font="700 22px system-ui";ctx.fillStyle="rgba(255,255,255,.72)";ctx.fillText("SHORTFACTORY V5",360,1185);
 ctx.globalAlpha=1;
}

$("#previewBtn").onclick=()=>{
 if(!scenes.length){toast("Lance d’abord l’agent.");return}
 if(previewHandle)cancelAnimationFrame(previewHandle);
 const start=performance.now();
 function tick(now){
  const elapsed=(now-start)/1000;
  if(elapsed>=DURATION){drawFrame(5,1);return}
  const i=Math.min(5,Math.floor(elapsed/SCENE_DURATION));
  drawFrame(i,(elapsed%SCENE_DURATION)/SCENE_DURATION);
  previewHandle=requestAnimationFrame(tick);
 }
 previewHandle=requestAnimationFrame(tick);
};

function narrationText(){return scenes.map(s=>s.narration).join(" ")}
$("#speakPreviewBtn").onclick=()=>{
 if(!("speechSynthesis" in window)){toast("Synthèse vocale non disponible.");return}
 speechSynthesis.cancel();
 const u=new SpeechSynthesisUtterance(narrationText());u.lang="fr-FR";u.rate=1.05;speechSynthesis.speak(u);
};

$("#recordBtn").onclick=async()=>{
 try{
  const stream=await navigator.mediaDevices.getUserMedia({audio:true});
  audioChunks=[];mediaRecorder=new MediaRecorder(stream);
  mediaRecorder.ondataavailable=e=>e.data.size&&audioChunks.push(e.data);
  mediaRecorder.onstop=()=>{audioBlob=new Blob(audioChunks,{type:mediaRecorder.mimeType});audioUrl=URL.createObjectURL(audioBlob);$("#audioPreview").src=audioUrl;$("#audioPreview").classList.remove("hidden");stream.getTracks().forEach(t=>t.stop());toast("Narration enregistrée.")};
  mediaRecorder.start();$("#recordBtn").disabled=true;$("#stopRecordBtn").disabled=false;toast("Enregistrement en cours…");
 }catch(e){toast("Autorisation microphone refusée.");}
};
$("#stopRecordBtn").onclick=()=>{if(mediaRecorder&&mediaRecorder.state!=="inactive")mediaRecorder.stop();$("#recordBtn").disabled=false;$("#stopRecordBtn").disabled=true};
$("#audioFile").onchange=e=>{const f=e.target.files[0];if(!f)return;audioBlob=f;audioUrl=URL.createObjectURL(f);$("#audioPreview").src=audioUrl;$("#audioPreview").classList.remove("hidden");toast("Audio ajouté.")};

$("#renderBtn").onclick=async()=>{
 if(!scenes.length){toast("Lance d’abord l’agent.");return}
 if(!canvas.captureStream||!window.MediaRecorder){toast("Cette WebView ne permet pas l’export vidéo.");return}
 $("#renderBtn").disabled=true;$("#renderProgress").classList.remove("hidden");$("#resultVideo").classList.add("hidden");$("#downloadBtn").classList.add("hidden");
 const canvasStream=canvas.captureStream(30);let finalStream=canvasStream,audioEl=null,audioCtx=null;
 if(audioUrl){
  try{
   audioEl=new Audio(audioUrl);audioCtx=new(window.AudioContext||window.webkitAudioContext)();
   const src=audioCtx.createMediaElementSource(audioEl),dest=audioCtx.createMediaStreamDestination();
   src.connect(dest);src.connect(audioCtx.destination);
   finalStream=new MediaStream([...canvasStream.getVideoTracks(),...dest.stream.getAudioTracks()]);
  }catch(e){console.warn(e)}
 }
 const candidates=["video/webm;codecs=vp9,opus","video/webm;codecs=vp8,opus","video/webm"];
 const mime=candidates.find(x=>MediaRecorder.isTypeSupported(x))||"";
 const rec=new MediaRecorder(finalStream,mime?{mimeType:mime,videoBitsPerSecond:5000000}:{videoBitsPerSecond:5000000});
 const chunks=[];rec.ondataavailable=e=>e.data.size&&chunks.push(e.data);
 const done=new Promise(r=>rec.onstop=r);
 rec.start(500);if(audioEl){audioEl.currentTime=0;audioEl.play().catch(()=>{})}
 const start=performance.now();
 await new Promise(resolve=>{
  function tick(now){
   const elapsed=(now-start)/1000,p=clamp(elapsed/DURATION,0,1);
   $("#renderBar").style.width=(p*100)+"%";$("#renderState").textContent=`Rendu ${Math.round(p*100)} % — scène ${Math.min(6,Math.floor(elapsed/5)+1)}/6`;
   if(elapsed>=DURATION){drawFrame(5,1);resolve();return}
   const i=Math.min(5,Math.floor(elapsed/SCENE_DURATION));drawFrame(i,(elapsed%SCENE_DURATION)/SCENE_DURATION);requestAnimationFrame(tick);
  }requestAnimationFrame(tick);
 });
 rec.stop();if(audioEl)audioEl.pause();await done;if(audioCtx)audioCtx.close();
 const blob=new Blob(chunks,{type:rec.mimeType||"video/webm"}),url=URL.createObjectURL(blob);
 $("#resultVideo").src=url;$("#resultVideo").classList.remove("hidden");
 $("#downloadBtn").href=url;$("#downloadBtn").download=`ShortFactory_V5_${Date.now()}.webm`;$("#downloadBtn").classList.remove("hidden");
 $("#renderState").textContent="Vidéo de 30 secondes terminée.";$("#renderBtn").disabled=false;toast("Vidéo générée.");
};

$("#diagBtn").onclick=()=>{
 const report={
  version:"5.0.0",
  date:new Date().toISOString(),
  userAgent:navigator.userAgent,
  mediaRecorder:!!window.MediaRecorder,
  canvasCapture:!!canvas.captureStream,
  speechSynthesis:"speechSynthesis" in window,
  androidBridge:hasBridge(),
  androidBridgeMethods:window.AndroidBridge?Object.keys(window.AndroidBridge):[],
  scenes:scenes.length,
  images:sceneImages.filter(Boolean).length
 };
 $("#diagnostic").textContent=JSON.stringify(report,null,2);
 const blob=new Blob([JSON.stringify(report,null,2)],{type:"application/json"});
 const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`diagnostic-shortfactory-v5-${Date.now()}.json`;a.click();
 setTimeout(()=>URL.revokeObjectURL(a.href),1000);
};

drawGeneratedVisual(ctx,720,1280,{seed:42,type:"technology"},.2,null);
})();
