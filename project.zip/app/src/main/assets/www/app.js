
const $=s=>document.querySelector(s);
const canvas=$("#canvas"),ctx=canvas.getContext("2d");
let scenes=[],audioBlob=null,audioUrl=null,recorder=null,chunks=[],previewHandle=null;

function toast(t){const e=$("#toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),2500)}
function esc(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function clamp(v,a,b){return Math.max(a,Math.min(b,v))}
function ease(t){return t<.5?2*t*t:1-Math.pow(-2*t+2,2)/2}
function hash(s){let h=0;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))|0;return Math.abs(h)}
function lines(text,max=24){const w=text.split(/\s+/),out=[];let l="";for(const x of w){let n=(l+" "+x).trim();if(n.length>max&&l){out.push(l);l=x}else l=n}if(l)out.push(l);return out.slice(0,7)}
function sceneType(text){
 const t=text.toLowerCase();
 if(/route|voiture|véhicule|transport|roule|train|ferroviaire/.test(t))return"transport";
 if(/maison|bâtiment|mur|béton|chantier|construction/.test(t))return"building";
 if(/feu|incendie|chaleur|flamme/.test(t))return"fire";
 if(/énergie|électricité|batterie|recharge|solaire/.test(t))return"energy";
 if(/robot|ia|intelligence|technologie|puce|donnée/.test(t))return"technology";
 if(/eau|mer|océan|pluie|hydrogène/.test(t))return"water";
 return"abstract";
}
function makeScript(subject,cta){
 const s=subject.trim();
 return[
  `Et si ${s.toLowerCase()} changeait complètement notre quotidien ?`,
  `Voici comment fonctionne ${s.toLowerCase()}.`,
  `Le système analyse la situation et déclenche une action en temps réel.`,
  `Son objectif : gagner du temps, réduire les coûts et améliorer la sécurité.`,
  `Mais cette technologie possède encore des limites à surveiller.`,
  cta
 ].map((text,i)=>({text,type:sceneType(text+" "+s),seed:hash(text+s+i)}));
}
$("#createBtn").onclick=()=>{
 const s=$("#subject").value.trim();if(s.length<5){toast("Entre un sujet précis.");return}
 scenes=makeScript(s,$("#cta").value.trim());
 renderEditor();$("#storyCard").classList.remove("hidden");$("#audioCard").classList.remove("hidden");$("#renderCard").classList.remove("hidden");drawScene(0,0);$("#storyCard").scrollIntoView({behavior:"smooth"});
};
function renderEditor(){
 $("#sceneEditor").innerHTML=scenes.map((s,i)=>`<div class="sceneRow"><div class="sceneTop"><b>Scène ${i+1}</b><span>${labelType(s.type)}</span></div><textarea data-i="${i}">${esc(s.text)}</textarea><div class="sceneType">Animation générée : ${labelType(s.type)}</div></div>`).join("");
 document.querySelectorAll("[data-i]").forEach(e=>e.oninput=ev=>{const i=+ev.target.dataset.i;scenes[i].text=ev.target.value;scenes[i].type=sceneType(ev.target.value+" "+$("#subject").value);});
}
function labelType(t){return({transport:"Route et véhicules",building:"Bâtiment animé",fire:"Feu et protection",energy:"Énergie et recharge",technology:"Réseau technologique",water:"Eau et fluides",abstract:"Animation générative"})[t]||t}
function bg(style,t,seed){
 const palettes={futuristic:[225,275],technical:[195,220],dramatic:[350,25],clean:[205,245]},p=palettes[style]||palettes.futuristic;
 const g=ctx.createLinearGradient(0,0,720,1280);g.addColorStop(0,`hsl(${p[0]} 58% 18%)`);g.addColorStop(1,`hsl(${p[1]} 68% 7%)`);ctx.fillStyle=g;ctx.fillRect(0,0,720,1280);
 for(let i=0;i<35;i++){const x=(seed*(i+9)*13+t*60*(i%4+1))%850-65,y=(seed*(i+4)*17+t*35*(i%3+1))%1410-65;ctx.beginPath();ctx.arc(x,y,2+(i%4),0,7);ctx.fillStyle=`rgba(110,210,255,${.06+(i%4)*.025})`;ctx.fill()}
}
function road(t){
 ctx.fillStyle="#111725";ctx.beginPath();ctx.moveTo(180,1280);ctx.lineTo(310,610);ctx.lineTo(410,610);ctx.lineTo(560,1280);ctx.closePath();ctx.fill();
 ctx.strokeStyle="rgba(255,255,255,.65)";ctx.lineWidth=8;ctx.setLineDash([45,35]);ctx.lineDashOffset=-t*140;ctx.beginPath();ctx.moveTo(360,1280);ctx.lineTo(360,620);ctx.stroke();ctx.setLineDash([]);
 for(let i=0;i<4;i++){const y=1050-((t*500+i*250)%750),scale=clamp((1200-y)/700,.25,1.1);car(270+(i%2)*150,y,scale,i%2)}
}
function car(x,y,s,flip){
 ctx.save();ctx.translate(x,y);ctx.scale((flip?-1:1)*s,s);ctx.fillStyle="#52d9ff";roundRect(-72,-28,144,55,18,true);ctx.fillStyle="#9ff3ff";roundRect(-38,-52,76,30,12,true);ctx.fillStyle="#070b15";for(const px of[-48,48]){ctx.beginPath();ctx.arc(px,28,15,0,7);ctx.fill()}ctx.restore()
}
function building(t){
 ctx.fillStyle="#121a2d";ctx.fillRect(75,500,570,650);for(let f=0;f<5;f++)for(let c=0;c<4;c++){const pulse=.25+.65*Math.max(0,Math.sin(t*4+f+c));ctx.fillStyle=`rgba(78,215,255,${pulse})`;ctx.fillRect(125+c*125,565+f*105,62,55)}
 ctx.strokeStyle="#8d70ff";ctx.lineWidth=8;ctx.beginPath();ctx.arc(360,480,65+t*15,Math.PI,Math.PI*2);ctx.stroke()
}
function fire(t){
 for(let i=0;i<20;i++){const x=220+(i*43%290),y=1000-(i%5)*45-Math.sin(t*8+i)*35,sz=55+(i%4)*18;ctx.beginPath();ctx.moveTo(x,y+sz);ctx.quadraticCurveTo(x-sz,y,x,y-sz*1.5);ctx.quadraticCurveTo(x+sz,y,x,y+sz);ctx.fillStyle=`hsla(${15+i%3*15},95%,55%,.55)`;ctx.fill()}
 ctx.strokeStyle="rgba(80,220,255,.8)";ctx.lineWidth=18;ctx.beginPath();ctx.arc(360,790,250,Math.PI*.12,Math.PI*.88);ctx.stroke()
}
function energy(t){
 ctx.strokeStyle="rgba(75,220,255,.85)";ctx.lineWidth=7;for(let i=0;i<7;i++){ctx.beginPath();for(let x=0;x<=720;x+=20){const y=690+i*28+Math.sin(x*.025+t*5+i)*18;ctx.lineTo(x,y)}ctx.stroke()}
 ctx.fillStyle="#141b2c";roundRect(215,390,290,155,28,true);ctx.fillStyle="#43d6ff";roundRect(240,420,245*(.35+.65*((t*.4)%1)),95,18,true);ctx.fillStyle="#fff";ctx.font="700 46px system-ui";ctx.textAlign="center";ctx.fillText("⚡",360,490)
}
function technology(t){
 const nodes=[];for(let i=0;i<18;i++){const a=i/18*Math.PI*2+t*.22,r=120+(i%4)*70;nodes.push([360+Math.cos(a)*r,710+Math.sin(a)*r])}
 ctx.strokeStyle="rgba(100,190,255,.28)";ctx.lineWidth=3;for(let i=0;i<nodes.length;i++){for(let j=i+1;j<nodes.length;j++){if((i+j)%5===0){ctx.beginPath();ctx.moveTo(...nodes[i]);ctx.lineTo(...nodes[j]);ctx.stroke()}}}
 nodes.forEach((n,i)=>{ctx.beginPath();ctx.arc(n[0],n[1],8+(i%3)*4,0,7);ctx.fillStyle=i%2?"#45d6ff":"#9b73ff";ctx.fill()})
 ctx.strokeStyle="#fff";ctx.lineWidth=6;ctx.strokeRect(270,575,180,180);ctx.fillStyle="rgba(140,104,255,.25)";ctx.fillRect(285,590,150,150)
}
function water(t){
 ctx.fillStyle="rgba(25,120,190,.3)";ctx.fillRect(0,660,720,620);for(let k=0;k<9;k++){ctx.strokeStyle=`rgba(80,210,255,${.18+k*.035})`;ctx.lineWidth=5;ctx.beginPath();for(let x=0;x<740;x+=18)ctx.lineTo(x,720+k*48+Math.sin(x*.025+t*4+k)*17);ctx.stroke()}
}
function abstract(t,seed){
 for(let i=0;i<18;i++){const a=t*(.25+i*.02)+i,rad=70+(i%6)*62,x=360+Math.cos(a)*rad,y=680+Math.sin(a*1.17)*rad;ctx.save();ctx.translate(x,y);ctx.rotate(a);ctx.fillStyle=`hsla(${(seed+i*22)%360},80%,62%,.38)`;roundRect(-35,-35,70,70,18,true);ctx.restore()}
}
function roundRect(x,y,w,h,r,fill){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();if(fill)ctx.fill()}
function textOverlay(text,lt){
 const alpha=clamp(Math.min(lt*5,(1-lt)*5),0,1);ctx.globalAlpha=alpha;ctx.fillStyle="rgba(0,0,0,.48)";roundRect(45,160,630,920,35,true);ctx.fillStyle="#fff";ctx.font="700 49px system-ui";ctx.textAlign="center";ctx.textBaseline="middle";const ls=lines(text,24),lh=67,total=ls.length*lh;ls.forEach((l,i)=>ctx.fillText(l,360,620-total/2+i*lh+lh/2,570));ctx.font="700 23px system-ui";ctx.fillStyle="rgba(255,255,255,.72)";ctx.fillText("SHORTFACTORY V3",360,1180);ctx.globalAlpha=1}
function drawScene(i,lt){
 const s=scenes[i]||{text:"ShortFactory V3",type:"technology",seed:11};bg($("#style").value,lt,s.seed);ctx.save();const zoom=1+.04*ease(lt);ctx.translate(360,640);ctx.scale(zoom,zoom);ctx.translate(-360,-640);
 ({transport:road,building,fire,energy,technology,water,abstract}[s.type]||abstract)(lt,s.seed);ctx.restore();textOverlay(s.text,lt)
}
function play(){
 if(previewHandle)cancelAnimationFrame(previewHandle);const dur=+$("#duration").value,start=performance.now();function tick(now){const t=(now-start)/1000;if(t>=dur){drawScene(scenes.length-1,1);return}const sd=dur/scenes.length,i=Math.min(scenes.length-1,Math.floor(t/sd)),lt=(t%sd)/sd;drawScene(i,lt);previewHandle=requestAnimationFrame(tick)}previewHandle=requestAnimationFrame(tick)
}
$("#previewBtn").onclick=play;
$("#audioFile").onchange=e=>{const f=e.target.files[0];if(!f)return;audioBlob=f;audioUrl=URL.createObjectURL(f);$("#audioPreview").src=audioUrl;$("#audioPreview").classList.remove("hidden");toast("Audio ajouté.")}
$("#recordBtn").onclick=async()=>{try{const stream=await navigator.mediaDevices.getUserMedia({audio:true});chunks=[];recorder=new MediaRecorder(stream);recorder.ondataavailable=e=>e.data.size&&chunks.push(e.data);recorder.onstop=()=>{audioBlob=new Blob(chunks,{type:recorder.mimeType});audioUrl=URL.createObjectURL(audioBlob);$("#audioPreview").src=audioUrl;$("#audioPreview").classList.remove("hidden");stream.getTracks().forEach(t=>t.stop());toast("Narration enregistrée.")};recorder.start();$("#recordBtn").disabled=true;$("#stopBtn").disabled=false;toast("Enregistrement…")}catch(e){toast("Autorisation microphone refusée.")}}
$("#stopBtn").onclick=()=>{if(recorder&&recorder.state!=="inactive")recorder.stop();$("#recordBtn").disabled=false;$("#stopBtn").disabled=true}
async function renderVideo(){
 if(!scenes.length){toast("Crée d’abord le scénario.");return}
 if(!canvas.captureStream||!window.MediaRecorder){toast("Cette WebView ne permet pas l’export vidéo.");return}
 const dur=+$("#duration").value;$("#renderBtn").disabled=true;$("#progressBox").classList.remove("hidden");$("#resultVideo").classList.add("hidden");$("#downloadBtn").classList.add("hidden");
 const cs=canvas.captureStream(30);let finalStream=cs,audioEl=null,audioCtx=null;
 if(audioUrl){try{audioEl=new Audio(audioUrl);audioCtx=new(window.AudioContext||window.webkitAudioContext)();const src=audioCtx.createMediaElementSource(audioEl),dest=audioCtx.createMediaStreamDestination();src.connect(dest);src.connect(audioCtx.destination);finalStream=new MediaStream([...cs.getVideoTracks(),...dest.stream.getAudioTracks()])}catch(e){console.warn(e)}}
 const types=["video/webm;codecs=vp9,opus","video/webm;codecs=vp8,opus","video/webm"],mime=types.find(x=>MediaRecorder.isTypeSupported(x))||"";
 const mr=new MediaRecorder(finalStream,mime?{mimeType:mime,videoBitsPerSecond:4500000}:{videoBitsPerSecond:4500000}),parts=[];mr.ondataavailable=e=>e.data.size&&parts.push(e.data);const done=new Promise(r=>mr.onstop=r);mr.start(500);if(audioEl){audioEl.currentTime=0;audioEl.play().catch(()=>{})}
 const start=performance.now();await new Promise(resolve=>{function tick(now){const t=(now-start)/1000,p=clamp(t/dur,0,1);$("#bar").style.width=(p*100)+"%";$("#progressText").textContent=`Rendu ${Math.round(p*100)} %`;if(t>=dur){drawScene(scenes.length-1,1);resolve();return}const sd=dur/scenes.length,i=Math.min(scenes.length-1,Math.floor(t/sd)),lt=(t%sd)/sd;drawScene(i,lt);requestAnimationFrame(tick)}requestAnimationFrame(tick)});mr.stop();if(audioEl)audioEl.pause();await done;if(audioCtx)audioCtx.close();
 const blob=new Blob(parts,{type:mr.mimeType||"video/webm"}),url=URL.createObjectURL(blob);$("#resultVideo").src=url;$("#resultVideo").classList.remove("hidden");$("#downloadBtn").href=url;$("#downloadBtn").download=`ShortFactory_V3_${Date.now()}.webm`;$("#downloadBtn").classList.remove("hidden");$("#progressText").textContent="Vidéo terminée.";$("#renderBtn").disabled=false;toast("Vidéo générée.")
}
$("#renderBtn").onclick=renderVideo;
scenes=[{text:"ShortFactory V3",type:"technology",seed:42}];drawScene(0,.3);scenes=[];
