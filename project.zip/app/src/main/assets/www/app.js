
(function(){
const E={
 fast:{name:"LTX Video Fast",owner:"Lightricks",space:"ltx-video-distilled",url:"https://lightricks-ltx-video-distilled.hf.space",page:"https://huggingface.co/spaces/Lightricks/ltx-video-distilled"},
 official:{name:"LTX 2.3 officiel",owner:"Lightricks",space:"LTX-2-3",url:"https://lightricks-ltx-2-3.hf.space",page:"https://huggingface.co/spaces/Lightricks/LTX-2-3"},
 studio:{name:"LTX 2.3 Studio",owner:"techfreakworm",space:"LTX2.3-Studio",url:"https://techfreakworm-ltx2-3-studio.hf.space",page:"https://huggingface.co/spaces/techfreakworm/LTX2.3-Studio"}
};
const ORDER=["fast","official","studio"];
const $=s=>document.querySelector(s);
let current=null,report=[],prepareTimer=null;
const toast=t=>{const x=$("#toast");x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),2400)};
function net(){const ok=navigator.onLine;$("#net").textContent=ok?"Internet disponible":"Hors connexion";$("#net").classList.toggle("ok",ok)}net();addEventListener("online",net);addEventListener("offline",net);
setTimeout(()=>$("#splash").classList.add("hide"),1600);

const styles={cinematic:"cinematic photorealistic film, realistic materials, natural lighting, professional color grading",documentary:"premium documentary footage, authentic natural light, physically accurate motion",future:"photorealistic near-future science fiction, believable technology, coherent geometry",advert:"premium commercial film, polished realistic lighting, elegant composition"};

$("#optimize").onclick=()=>{
 const s=$("#subject").value.trim();
 if(s.length<10){toast("Décris davantage la scène.");return}
 $("#prompt").value=[s,styles[$("#style").value],$("#camera").value,"smooth physically plausible movement","consistent objects and geometry","natural motion blur","rich fine details",`composition optimized for ${$("#ratio").value}`,"one continuous three-second shot","no visible text"].join(", ")+".";
 $("#negativePrompt").value=$("#negative").value.trim();
 $("#promptCard").classList.remove("hidden");
 $("#promptCard").scrollIntoView({behavior:"smooth"});
};

async function copy(){
 const p=$("#prompt").value.trim();
 if(!p){toast("Crée le prompt.");return false}
 const text=`POSITIVE PROMPT:\n${p}\n\nNEGATIVE PROMPT:\n${$("#negativePrompt").value.trim()}\n\nDURATION: 2-3 seconds\nFORMAT: ${$("#ratio").value}`;
 try{await navigator.clipboard.writeText(text)}
 catch(e){const a=document.createElement("textarea");a.value=text;document.body.appendChild(a);a.select();document.execCommand("copy");a.remove()}
 toast("Prompt copié.");return true;
}
$("#copy").onclick=copy;

async function check(k){
 const e=E[k],start=Date.now();
 try{
  const c=new AbortController(),tm=setTimeout(()=>c.abort(),9000);
  const r=await fetch(`https://huggingface.co/api/spaces/${e.owner}/${e.space}`,{signal:c.signal,cache:"no-store"});
  clearTimeout(tm);
  const data=await r.json();
  const stage=(data.runtime&&data.runtime.stage)||"UNKNOWN";
  const ok=r.ok&&!["STOPPED","PAUSED","BUILDING","RUNTIME_ERROR"].includes(stage);
  const out={k,ok,status:r.status,stage,ms:Date.now()-start};
  report.push(out);return out;
 }catch(err){
  const out={k,ok:false,status:0,stage:err.message,ms:Date.now()-start};
  report.push(out);return out;
 }
}
function render(xs){
 $("#engines").innerHTML=xs.map(x=>`<div class="status"><div><b>${E[x.k].name}</b><small>${x.stage||"Statut inconnu"} · ${x.ms} ms</small></div><span class="tag ${x.ok?"ok":"bad"}">${x.ok?"Disponible":"Indisponible"}</span></div>`).join("");
}
async function test(open){
 $("#statusCard").classList.remove("hidden");$("#summary").textContent="Vérification…";report=[];
 const xs=[];
 for(const k of ORDER){
  const r=await check(k);xs.push(r);render(xs);
  if(open&&r.ok){$("#summary").textContent=E[k].name+" est disponible.";await copy();openEngine(k);$("#diag").textContent=JSON.stringify(report,null,2);return}
 }
 $("#summary").textContent=xs.some(x=>x.ok)?"Des moteurs sont disponibles.":"Aucun moteur disponible.";
 $("#diag").textContent=JSON.stringify(report,null,2);
}
$("#auto").onclick=()=>test(true);$("#diagBtn").onclick=()=>test(false);

function startPrepareTimer(){
 clearTimeout(prepareTimer);
 $("#prepareNotice").classList.add("hidden");
 prepareTimer=setTimeout(()=>{
   $("#prepareNotice").classList.remove("hidden");
   $("#modalHint").textContent="Le moteur tarde à démarrer.";
 },45000);
}
function openEngine(k){
 current=k;
 $("#modalTitle").textContent=E[k].name;
 $("#modalHint").textContent="Le prompt est copié : colle-le dans le générateur.";
 $("#frame").src=E[k].url+"/?__theme=dark";
 $("#modal").classList.remove("hidden");
 startPrepareTimer();
}
async function nextEngine(){
 if(!current)return;
 const start=ORDER.indexOf(current);
 for(let i=1;i<=ORDER.length;i++){
   const k=ORDER[(start+i)%ORDER.length];
   const r=await check(k);
   if(r.ok){await copy();openEngine(k);toast("Bascule vers "+E[k].name);return}
 }
 toast("Aucun autre moteur disponible.");
}
document.querySelectorAll("[data-key]").forEach(b=>b.onclick=async()=>{
 const k=b.dataset.key,r=await check(k);
 if(!r.ok){toast("Ce moteur est actuellement indisponible.");$("#diag").textContent=JSON.stringify(report,null,2);return}
 await copy();openEngine(k);
});
function openChrome(){if(current)window.open(E[current].page,"_blank")}
$("#browser").onclick=openChrome;$("#noticeChrome").onclick=openChrome;
$("#nextEngine").onclick=nextEngine;$("#noticeNext").onclick=nextEngine;
$("#close").onclick=()=>{clearTimeout(prepareTimer);$("#frame").src="about:blank";$("#prepareNotice").classList.add("hidden");$("#modal").classList.add("hidden")};

$("#downloadDiagBtn").onclick=()=>{
 const data={date:new Date().toISOString(),online:navigator.onLine,userAgent:navigator.userAgent,engines:report};
 const blob=new Blob([JSON.stringify(data,null,2)],{type:"application/json"});
 const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download=`diagnostic-shortfactory-v4-4-${Date.now()}.json`;a.click();
 setTimeout(()=>URL.revokeObjectURL(a.href),1000);
};
})();
