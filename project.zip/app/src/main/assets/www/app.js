
(function(){
"use strict";
const $=s=>document.querySelector(s),canvas=$("#canvas"),ctx=canvas.getContext("2d");
let scenes=[],images=new Array(6).fill(null),cancelRequested=false,audioUrl=null,previewId=null;
const DURATION=30,SCENE_DURATION=5;
const toast=t=>{const e=$("#toast");e.textContent=t;e.classList.add("show");setTimeout(()=>e.classList.remove("show"),2600)};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
setTimeout(()=>$("#splash").classList.add("hide"),1600);

function puterReady(){return !!(window.puter&&puter.ai&&typeof puter.ai.txt2img==="function")}
function updatePuterStatus(){
 const ready=puterReady();
 $("#statusBadge").textContent=ready?"Puter AI disponible":"Puter indisponible";
 $("#statusBadge").classList.toggle("ok",ready);
 if(ready){
  const signed=puter.auth&&puter.auth.isSignedIn&&puter.auth.isSignedIn();
  $("#accountState").textContent=signed?"Compte Puter connecté":"Non connecté";
  $("#accountDetail").textContent=signed?"Le moteur IA peut être utilisé.":"La connexion sera demandée à la première utilisation.";
 }
}
setTimeout(updatePuterStatus,1800);

$("#loginBtn").onclick=async()=>{
 if(!puterReady()){toast("Puter.js n’est pas chargé. Vérifie Internet.");return}
 try{
  await puter.auth.signIn({attempt_temp_user_creation:true});
  updatePuterStatus();toast("Connexion Puter réussie.");
 }catch(e){toast(errorText(e));}
};

const styleMap={
 cinematic:"cinematic photorealistic film, realistic materials, natural lighting, professional color grading, rich fine details",
 documentary:"premium documentary photography, authentic natural environment, realistic light, clear visual storytelling",
 future:"photorealistic near-future technology, believable engineering, coherent geometry, cinematic lighting",
 advert:"premium commercial photography, luxury advertising quality, elegant composition, polished realistic details",
 technical:"realistic technical visualization, educational clarity, precise objects, clean professional composition"
};

function createPlan(subject,cta){
 const s=subject.trim();
 const bible=`The exact same main subject in every scene: ${s}. Maintain the same design, materials, colors, proportions and visual identity throughout all six images. ${styleMap[$("#style").value]}. Vertical composition optimized for ${$("#ratio").value}. No visible text, no logo, no watermark.`;
 return {bible, scenes:[
  {title:"Accroche",narration:`Et si ${s.toLowerCase()} pouvait transformer notre quotidien ?`,visual:`Spectacular establishing shot introducing ${s}, immediate visual hook, dramatic but believable environment, low cinematic camera angle.`},
  {title:"Le problème",narration:"Aujourd’hui, cette innovation répond à un problème concret que beaucoup de personnes rencontrent.",visual:`Show the real-world problem that exists before ${s} is used, clear visual contrast, realistic situation, emotionally engaging composition.`},
  {title:"Le fonctionnement",narration:"Le principe est simple : des capteurs analysent la situation et le système agit automatiquement.",visual:`Detailed visual demonstration of how ${s} works, visible technology, sensors and energy flow, believable physical mechanism, coherent engineering.`},
  {title:"Les bénéfices",narration:"Cette solution pourrait faire gagner du temps, réduire les coûts et améliorer la sécurité.",visual:`Show the practical benefits of ${s} in real life, efficient operation, safer environment, confident positive atmosphere.`},
  {title:"Les limites",narration:"Son prix, sa fiabilité et son impact réel doivent pourtant encore être vérifiés.",visual:`Balanced realistic scene showing practical limitations or challenges of ${s}, thoughtful mood, credible details, no disaster fantasy.`},
  {title:"Conclusion",narration:cta,visual:`Memorable cinematic conclusion showing ${s} working successfully in a believable future, wider camera view, hopeful final lighting.`}
 ]};
}

$("#agentBtn").onclick=async()=>{
 const subject=$("#subject").value.trim();
 if(subject.length<8){toast("Décris un sujet plus précisément.");return}
 $("#storyCard").classList.remove("hidden");$("#storyBar").style.width="10%";$("#storyState").textContent="Analyse du sujet…";
 await sleep(300);$("#storyBar").style.width="35%";$("#storyState").textContent="Création de la fiche de cohérence…";
 const plan=createPlan(subject,$("#cta").value.trim());
 $("#visualBible").value=plan.bible;scenes=plan.scenes;images=new Array(6).fill(null);
 await sleep(300);$("#storyBar").style.width="70%";$("#storyState").textContent="Écriture des six scènes…";
 renderScenes();
 await sleep(300);$("#storyBar").style.width="100%";$("#storyState").textContent="Scénario de 30 secondes terminé.";
 $("#generateCard").classList.remove("hidden");$("#audioCard").classList.remove("hidden");$("#renderCard").classList.remove("hidden");
 drawFrame(0,0);$("#storyCard").scrollIntoView({behavior:"smooth"});
};

function renderScenes(){
 $("#sceneList").innerHTML=scenes.map((s,i)=>`
 <div class="scene">
  <div class="sceneHead"><b>Scène ${i+1} — ${s.title}</b><span>5 secondes</span></div>
  <label>Narration<textarea data-narration="${i}">${esc(s.narration)}</textarea></label>
  <label>Prompt<textarea data-prompt="${i}">${esc(s.visual)}</textarea></label>
  <div id="visual${i}" class="placeholder">Image IA non générée</div>
  <div class="sceneActions">
   <button class="secondary generateOne" data-i="${i}">Générer cette image</button>
   <label class="secondary fileButton">Importer<input class="sceneFile" data-i="${i}" type="file" accept="image/*"></label>
  </div>
 </div>`).join("");
 document.querySelectorAll("[data-narration]").forEach(x=>x.oninput=e=>scenes[+e.target.dataset.narration].narration=e.target.value);
 document.querySelectorAll("[data-prompt]").forEach(x=>x.oninput=e=>scenes[+e.target.dataset.prompt].visual=e.target.value);
 document.querySelectorAll(".generateOne").forEach(x=>x.onclick=()=>generateScene(+x.dataset.i));
 document.querySelectorAll(".sceneFile").forEach(x=>x.onchange=e=>importImage(+x.dataset.i,e.target.files[0]));
}

function esc(s){return s.replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function fullPrompt(i){
 return `${$("#visualBible").value.trim()} SCENE ${i+1}: ${scenes[i].visual} Keep exact subject consistency with the previous scenes. Natural perspective, physically plausible geometry, no duplicated objects, no malformed details.`;
}
function errorText(e){
 return e?.msg||e?.message||e?.error||String(e||"Erreur inconnue");
}

async function elementToDataUrl(el){
 if(!el)return null;
 if(typeof el==="string")return el;
 if(el.src)return el.src;
 if(el.url)return el.url;
 if(el.image?.src)return el.image.src;
 throw new Error("Format d’image Puter non reconnu.");
}

async function loadImage(src){
 return new Promise((resolve,reject)=>{
  const im=new Image();im.crossOrigin="anonymous";
  im.onload=()=>resolve(im);im.onerror=()=>reject(new Error("Impossible de charger l’image générée."));
  im.src=src;
 });
}

async function generateScene(i){
 if(!puterReady())throw new Error("Puter.js n’est pas chargé. Active Internet et JavaScript.");
 const test=$("#testMode").checked,model=$("#imageModel").value,quality=$("#quality").value;
 $("#imageState").textContent=`Scène ${i+1}/6 : envoi du prompt à Puter AI…`;
 const options={test_mode:test,quality};
 if(model)options.model=model;
 let result;
 try{
  result=await puter.ai.txt2img({prompt:fullPrompt(i),...options});
 }catch(first){
  if(model){
   $("#imageState").textContent=`Le modèle choisi a échoué. Nouvel essai avec le modèle par défaut…`;
   result=await puter.ai.txt2img({prompt:fullPrompt(i),test_mode:test,quality});
  }else throw first;
 }
 const src=await elementToDataUrl(result),im=await loadImage(src);
 images[i]=im;showImage(i,src);drawFrame(i,.25);return true;
}

function showImage(i,src){
 const old=$("#visual"+i);if(!old)return;
 const img=document.createElement("img");img.id=`visual${i}`;img.src=src;img.alt=`Image IA de la scène ${i+1}`;
 old.replaceWith(img);
}
function importImage(i,file){
 if(!file)return;const src=URL.createObjectURL(file);
 loadImage(src).then(im=>{images[i]=im;showImage(i,src);drawFrame(i,.25);toast(`Image ${i+1} importée.`)});
}

async function generateMissing(onlyMissing){
 cancelRequested=false;$("#cancelBtn").disabled=false;$("#generateAllBtn").disabled=true;$("#resumeBtn").disabled=true;
 try{
  for(let i=0;i<6;i++){
   if(cancelRequested)break;
   if(onlyMissing&&images[i])continue;
   $("#imageBar").style.width=((i+.15)/6*100)+"%";
   try{await generateScene(i);$("#imageState").textContent=`Scène ${i+1}/6 terminée.`}
   catch(e){$("#imageState").textContent=`Erreur scène ${i+1}: ${errorText(e)}`;toast(`Échec scène ${i+1}. Tu pourras la relancer.`)}
   $("#imageBar").style.width=((i+1)/6*100)+"%";
  }
  if(!cancelRequested)$("#imageState").textContent=`${images.filter(Boolean).length}/6 images prêtes.`;
 }finally{$("#cancelBtn").disabled=true;$("#generateAllBtn").disabled=false;$("#resumeBtn").disabled=false}
}
$("#generateAllBtn").onclick=()=>generateMissing(false);
$("#resumeBtn").onclick=()=>generateMissing(true);
$("#cancelBtn").onclick=()=>{cancelRequested=true;$("#imageState").textContent="Arrêt demandé après la scène en cours."};

$("#speakBtn").onclick=()=>{
 if(!scenes.length)return;
 speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(scenes.map(s=>s.narration).join(" "));u.lang="fr-FR";u.rate=1.06;speechSynthesis.speak(u);
};
$("#audioFile").onchange=e=>{const f=e.target.files[0];if(!f)return;audioUrl=URL.createObjectURL(f);$("#audioPreview").src=audioUrl;$("#audioPreview").classList.remove("hidden")};

function splitLines(text,max=27){
 const a=[],words=text.split(/\s+/);let line="";
 for(const w of words){const t=(line+" "+w).trim();if(t.length>max&&line){a.push(line);line=w}else line=t}if(line)a.push(line);return a.slice(0,7)
}
function drawFrame(i,t){
 const s=scenes[i]||{narration:"ShortFactory V6"};ctx.fillStyle="#050814";ctx.fillRect(0,0,720,1280);
 const im=images[i];
 if(im){
  const ratio=im.width/im.height,cr=720/1280;let w,h;
  const zoom=1.06+t*.07;
  if(ratio>cr){h=1280*zoom;w=h*ratio}else{w=720*zoom;h=w/ratio}
  const pan=(i%2?1:-1)*(t-.5)*40;
  ctx.drawImage(im,(720-w)/2+pan,(1280-h)/2,w,h);
 }else{
  const g=ctx.createLinearGradient(0,0,720,1280);g.addColorStop(0,"#1c315d");g.addColorStop(1,"#080b18");ctx.fillStyle=g;ctx.fillRect(0,0,720,1280);
  ctx.fillStyle="rgba(80,210,255,.16)";for(let k=0;k<24;k++){ctx.beginPath();ctx.arc((k*137+t*80)%800-40,(k*211+t*45)%1360-40,12+(k%5)*7,0,7);ctx.fill()}
 }
 const fade=clamp(Math.min(t*6,(1-t)*6),0,1);ctx.globalAlpha=fade;
 ctx.fillStyle="rgba(0,0,0,.48)";round(45,170,630,900,34);ctx.fill();
 const lines=splitLines(s.narration),lh=64,total=lines.length*lh;
 ctx.fillStyle="#fff";ctx.textAlign="center";ctx.textBaseline="middle";ctx.font="700 46px system-ui";
 lines.forEach((l,n)=>ctx.fillText(l,360,620-total/2+n*lh+lh/2,570));
 ctx.font="700 21px system-ui";ctx.fillStyle="rgba(255,255,255,.72)";ctx.fillText("SHORTFACTORY V6",360,1185);ctx.globalAlpha=1;
}
function round(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath()}

$("#previewBtn").onclick=()=>{
 if(!scenes.length)return;if(previewId)cancelAnimationFrame(previewId);const start=performance.now();
 const tick=now=>{const e=(now-start)/1000;if(e>=30){drawFrame(5,1);return}const i=Math.min(5,Math.floor(e/5));drawFrame(i,(e%5)/5);previewId=requestAnimationFrame(tick)};previewId=requestAnimationFrame(tick);
};

$("#renderBtn").onclick=async()=>{
 if(!scenes.length){toast("Crée d’abord le scénario.");return}
 if(!canvas.captureStream||!window.MediaRecorder){toast("Export vidéo non pris en charge par cette WebView.");return}
 $("#renderBtn").disabled=true;$("#renderProgress").classList.remove("hidden");
 const videoStream=canvas.captureStream(30);let stream=videoStream,audio=null,ac=null;
 if(audioUrl)try{
  audio=new Audio(audioUrl);ac=new(window.AudioContext||window.webkitAudioContext)();const src=ac.createMediaElementSource(audio),dest=ac.createMediaStreamDestination();src.connect(dest);src.connect(ac.destination);stream=new MediaStream([...videoStream.getVideoTracks(),...dest.stream.getAudioTracks()]);
 }catch(e){}
 const types=["video/webm;codecs=vp9,opus","video/webm;codecs=vp8,opus","video/webm"],mime=types.find(x=>MediaRecorder.isTypeSupported(x))||"";
 const rec=new MediaRecorder(stream,mime?{mimeType:mime,videoBitsPerSecond:5500000}:{videoBitsPerSecond:5500000}),chunks=[];
 rec.ondataavailable=e=>e.data.size&&chunks.push(e.data);const done=new Promise(r=>rec.onstop=r);rec.start(500);if(audio){audio.currentTime=0;audio.play().catch(()=>{})}
 const start=performance.now();
 await new Promise(resolve=>{const tick=now=>{const e=(now-start)/1000,p=clamp(e/30,0,1);$("#renderBar").style.width=p*100+"%";$("#renderState").textContent=`Rendu ${Math.round(p*100)} %`;if(e>=30){drawFrame(5,1);resolve();return}const i=Math.min(5,Math.floor(e/5));drawFrame(i,(e%5)/5);requestAnimationFrame(tick)};requestAnimationFrame(tick)});
 rec.stop();if(audio)audio.pause();await done;if(ac)ac.close();
 const blob=new Blob(chunks,{type:rec.mimeType||"video/webm"}),url=URL.createObjectURL(blob);$("#videoResult").src=url;$("#videoResult").classList.remove("hidden");$("#downloadBtn").href=url;$("#downloadBtn").download=`ShortFactory_V6_${Date.now()}.webm`;$("#downloadBtn").classList.remove("hidden");$("#renderState").textContent="Vidéo de 30 secondes terminée.";$("#renderBtn").disabled=false;toast("Vidéo prête.");
};

$("#diagBtn").onclick=()=>{
 const d={version:"6.0.0",date:new Date().toISOString(),online:navigator.onLine,puterReady:puterReady(),signedIn:puterReady()&&puter.auth.isSignedIn(),testMode:$("#testMode").checked,model:$("#imageModel").value||"default",images:images.filter(Boolean).length,mediaRecorder:!!window.MediaRecorder,canvasCapture:!!canvas.captureStream,userAgent:navigator.userAgent};
 $("#diagnostic").textContent=JSON.stringify(d,null,2);const b=new Blob([JSON.stringify(d,null,2)],{type:"application/json"}),a=document.createElement("a");a.href=URL.createObjectURL(b);a.download=`diagnostic-shortfactory-v6-${Date.now()}.json`;a.click();
};
drawFrame(0,.2);
})();
