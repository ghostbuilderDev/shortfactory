
(function(){
"use strict";

const $=s=>document.querySelector(s);
const canvas=$("#canvas");
const ctx=canvas.getContext("2d",{alpha:false});
const DURATION=30;
const SCENE_DURATION=5;

let scenes=[];
let selections=new Array(6).fill(null);
let prepared=new Array(6).fill(null);
let searchResults=new Array(6).fill(null).map(()=>[]);
let stopPreparing=false;
let previewFrame=null;
let currentMode=null;
let currentActive=-1;
let audioUrl=null;
let projectId=Date.now();

const toast=t=>{
  const e=$("#toast");
  e.textContent=t;
  e.classList.add("show");
  setTimeout(()=>e.classList.remove("show"),2600);
};
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const esc=s=>String(s||"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]));

setTimeout(()=>$("#splash").classList.add("hide"),1400);

function updateNetwork(){
  const ok=navigator.onLine;
  $("#networkBadge").textContent=ok?"Internet disponible":"Hors connexion";
  $("#networkBadge").classList.toggle("ok",ok);
}
updateNetwork();
addEventListener("online",updateNetwork);
addEventListener("offline",updateNetwork);

function saveKeys(){
  localStorage.setItem("sf7_pexels_key",$("#pexelsKey").value.trim());
  localStorage.setItem("sf7_pixabay_key",$("#pixabayKey").value.trim());
  toast("Clés enregistrées sur ce téléphone.");
}
function loadKeys(){
  $("#pexelsKey").value=localStorage.getItem("sf7_pexels_key")||"";
  $("#pixabayKey").value=localStorage.getItem("sf7_pixabay_key")||"";
}
loadKeys();

$("#saveKeysBtn").onclick=saveKeys;
$("#clearKeysBtn").onclick=()=>{
  localStorage.removeItem("sf7_pexels_key");
  localStorage.removeItem("sf7_pixabay_key");
  $("#pexelsKey").value="";
  $("#pixabayKey").value="";
  toast("Clés effacées.");
};
document.querySelectorAll("[data-toggle-key]").forEach(btn=>{
  btn.onclick=()=>{
    const el=$("#"+btn.dataset.toggleKey);
    el.type=el.type==="password"?"text":"password";
  };
});
document.querySelectorAll("[data-open]").forEach(btn=>{
  btn.onclick=()=>window.open(btn.dataset.open,"_blank");
});

async function pexelsSearch(query,perPage=6){
  const key=$("#pexelsKey").value.trim();
  if(!key)throw new Error("Clé Pexels absente.");
  const orientation=$("#orientation").value;
  const url="https://api.pexels.com/v1/videos/search?"+
    new URLSearchParams({
      query,
      orientation,
      size:"small",
      locale:"fr-FR",
      per_page:String(perPage)
    });
  const r=await fetch(url,{headers:{Authorization:key},cache:"no-store"});
  if(!r.ok){
    const text=await r.text().catch(()=> "");
    throw new Error(`Pexels ${r.status}: ${text||r.statusText}`);
  }
  const data=await r.json();
  return (data.videos||[]).map(normalizePexels).filter(Boolean);
}

function choosePexelsFile(video){
  const files=(video.video_files||[]).filter(f=>f.file_type==="video/mp4"&&f.link&&f.width&&f.height);
  const targetOrientation=$("#orientation").value;
  const portrait=targetOrientation==="portrait";
  const square=targetOrientation==="square";
  files.sort((a,b)=>{
    const score=f=>{
      const isPortrait=f.height>f.width;
      const isSquare=Math.abs(f.height-f.width)/Math.max(f.height,f.width)<.14;
      const orientationScore=square?(isSquare?100:0):(portrait?(isPortrait?100:0):(!isPortrait?100:0));
      const pixels=f.width*f.height;
      const sizeScore=pixels>=350000&&pixels<=2200000?40:0;
      const targetDistance=Math.abs(Math.max(f.width,f.height)-1280)/40;
      return orientationScore+sizeScore-targetDistance;
    };
    return score(b)-score(a);
  });
  return files[0]||null;
}

function normalizePexels(v){
  const f=choosePexelsFile(v);
  if(!f||Number(v.duration)<4.5)return null;
  return {
    id:"pexels-"+v.id,
    provider:"Pexels",
    providerKey:"pexels",
    pageUrl:v.url,
    author:v.user?.name||"Créateur Pexels",
    authorUrl:v.user?.url||v.url,
    duration:Number(v.duration)||5,
    width:Number(f.width)||0,
    height:Number(f.height)||0,
    videoUrl:f.link,
    thumbnail:v.image||(v.video_pictures?.[0]?.picture||""),
    popularity:0
  };
}

async function pixabaySearch(query,perPage=8){
  const key=$("#pixabayKey").value.trim();
  if(!key)throw new Error("Clé Pixabay absente.");
  const url="https://pixabay.com/api/videos/?"+
    new URLSearchParams({
      key,
      q:query.slice(0,100),
      lang:"fr",
      video_type:"film",
      safesearch:"true",
      order:"popular",
      per_page:String(Math.max(3,perPage))
    });
  const r=await fetch(url,{cache:"no-store"});
  if(!r.ok){
    const text=await r.text().catch(()=> "");
    throw new Error(`Pixabay ${r.status}: ${text||r.statusText}`);
  }
  const data=await r.json();
  return (data.hits||[]).map(normalizePixabay).filter(Boolean);
}

function choosePixabayFile(hit){
  const versions=hit.videos||{};
  const list=["small","medium","tiny","large"].map(k=>versions[k]).filter(v=>v&&v.url&&v.width&&v.height);
  const target=$("#orientation").value;
  list.sort((a,b)=>{
    const score=f=>{
      const portrait=f.height>f.width;
      const square=Math.abs(f.height-f.width)/Math.max(f.height,f.width)<.14;
      const orientationScore=target==="portrait"?(portrait?100:0):target==="square"?(square?100:0):(!portrait?100:0);
      const pixels=f.width*f.height;
      return orientationScore+(pixels>=300000&&pixels<=2300000?30:0)-Math.abs(Math.max(f.width,f.height)-1280)/50;
    };
    return score(b)-score(a);
  });
  return list[0]||null;
}

function normalizePixabay(hit){
  const f=choosePixabayFile(hit);
  if(!f||Number(hit.duration)<4.5)return null;
  return {
    id:"pixabay-"+hit.id,
    provider:"Pixabay",
    providerKey:"pixabay",
    pageUrl:hit.pageURL,
    author:hit.user||"Créateur Pixabay",
    authorUrl:`https://pixabay.com/users/${encodeURIComponent(hit.user||"")}-${hit.user_id||""}/`,
    duration:Number(hit.duration)||5,
    width:Number(f.width)||0,
    height:Number(f.height)||0,
    videoUrl:f.url,
    thumbnail:f.thumbnail||"",
    popularity:Number(hit.likes||0)+Number(hit.downloads||0)/100
  };
}

function scoreCandidate(c){
  const target=$("#orientation").value;
  const portrait=c.height>c.width;
  const square=Math.abs(c.height-c.width)/Math.max(c.height,c.width)<.14;
  const orientationScore=target==="portrait"?(portrait?120:-25):target==="square"?(square?120:0):(!portrait?100:0);
  const durationScore=c.duration>=5&&c.duration<=30?45:c.duration>=5?20:-100;
  const res=Math.min(c.width,c.height);
  const resolutionScore=res>=720?35:res>=480?18:0;
  return orientationScore+durationScore+resolutionScore+Math.min(20,c.popularity/100);
}

function dedupe(items){
  const seen=new Set();
  return items.filter(x=>x&&!seen.has(x.id)&&(seen.add(x.id),true));
}

$("#testKeysBtn").onclick=async()=>{
  saveKeys();
  $("#apiState").textContent="Test des API…";
  const messages=[];
  if($("#pexelsKey").value.trim()){
    try{
      const x=await pexelsSearch("nature",3);
      messages.push(`Pexels OK (${x.length} résultat(s))`);
    }catch(e){messages.push(e.message);}
  }else messages.push("Pexels : clé absente");
  if($("#pixabayKey").value.trim()){
    try{
      const x=await pixabaySearch("nature",3);
      messages.push(`Pixabay OK (${x.length} résultat(s))`);
    }catch(e){messages.push(e.message);}
  }else messages.push("Pixabay : clé facultative absente");
  $("#apiState").textContent=messages.join(" · ");
};

function detectTopic(subject){
  const s=subject.toLowerCase();
  if(/incend|feu|forêt|flamme/.test(s))return"wildfire";
  if(/maison|habitat|construction|chantier|bâtiment|isolation/.test(s))return"house";
  if(/voiture|route|autoroute|électrique|véhicule|mobilité/.test(s))return"car";
  if(/train|ferroviaire|rail|gare/.test(s))return"rail";
  if(/énergie|solaire|batterie|électricité|éolienne/.test(s))return"energy";
  if(/robot|intelligence artificielle| ia |technologie|innovation/.test(" "+s+" "))return"technology";
  if(/mer|océan|eau|pluie|inondation/.test(s))return"water";
  return"generic";
}

function makeQueries(subject){
  const topic=detectTopic(subject);
  const maps={
    wildfire:[
      "modern house near forest aerial",
      "wildfire smoke approaching houses",
      "smart home security sensors close up",
      "house exterior sprinkler system",
      "firefighters monitoring wildfire technology",
      "safe modern house after wildfire"
    ],
    house:[
      "modern house exterior cinematic",
      "home construction problem inspection",
      "smart home technology close up",
      "home renovation professional work",
      "building inspection challenge",
      "beautiful finished modern house"
    ],
    car:[
      "electric car driving city cinematic",
      "traffic pollution city cars",
      "electric vehicle technology close up",
      "electric car charging innovation",
      "automotive engineering test",
      "future electric mobility city"
    ],
    rail:[
      "modern train railway aerial",
      "railway maintenance workers",
      "railway technology close up",
      "high speed train infrastructure",
      "railway safety inspection",
      "modern train journey cinematic"
    ],
    energy:[
      "renewable energy landscape cinematic",
      "energy problem city industry",
      "battery technology close up",
      "solar wind energy solution",
      "energy engineers inspection",
      "clean energy future city"
    ],
    technology:[
      "future technology cinematic opening",
      "everyday problem people technology",
      "smart sensors technology close up",
      "innovation improving daily life",
      "technology testing laboratory",
      "successful innovation future"
    ],
    water:[
      "water nature aerial cinematic",
      "water crisis city environment",
      "water treatment technology close up",
      "clean water solution people",
      "water engineers inspection",
      "clean water future community"
    ],
    generic:[
      `${subject} cinematic`,
      `${subject} problem`,
      `${subject} technology`,
      `${subject} solution`,
      `${subject} challenge`,
      `${subject} success`
    ]
  };
  return maps[topic];
}

function createStory(subject,cta){
  const queries=makeQueries(subject);
  return[
    {title:"Accroche",narration:`Et si ${subject.toLowerCase()} pouvait transformer notre quotidien ?`,query:queries[0]},
    {title:"Le problème",narration:"Aujourd’hui, cette idée répond à un problème concret que beaucoup de personnes rencontrent.",query:queries[1]},
    {title:"Le fonctionnement",narration:"Le principe est simple : des capteurs et des équipements analysent la situation puis agissent automatiquement.",query:queries[2]},
    {title:"Les bénéfices",narration:"Cette solution pourrait faire gagner du temps, réduire les coûts et améliorer la sécurité.",query:queries[3]},
    {title:"Les limites",narration:"Son prix, sa fiabilité et son efficacité réelle doivent toutefois être vérifiés.",query:queries[4]},
    {title:"Conclusion",narration:cta,query:queries[5]}
  ];
}

$("#agentBtn").onclick=async()=>{
  const subject=$("#subject").value.trim();
  if(subject.length<8){toast("Décris le sujet plus précisément.");return;}
  projectId=Date.now();
  scenes=createStory(subject,$("#cta").value.trim());
  selections=new Array(6).fill(null);
  prepared.forEach(x=>{if(x?.objectUrl)URL.revokeObjectURL(x.objectUrl);});
  prepared=new Array(6).fill(null);
  searchResults=new Array(6).fill(null).map(()=>[]);
  $("#storyCard").classList.remove("hidden");
  $("#storyBar").style.width="12%";
  $("#storyState").textContent="Analyse du sujet…";
  await sleep(250);
  $("#storyBar").style.width="45%";
  $("#storyState").textContent="Découpage en six scènes…";
  await sleep(250);
  renderStory();
  $("#storyBar").style.width="82%";
  $("#storyState").textContent="Création des recherches vidéo…";
  await sleep(250);
  $("#storyBar").style.width="100%";
  $("#storyState").textContent="Scénario de 30 secondes terminé.";
  $("#storyCard").scrollIntoView({behavior:"smooth"});
  drawPlaceholder();
};

function renderStory(){
  $("#sceneList").innerHTML=scenes.map((s,i)=>`
    <div class="scene">
      <div class="sceneHead"><b>Scène ${i+1} — ${esc(s.title)}</b><span>5 secondes</span></div>
      <label>Narration<textarea data-narration="${i}">${esc(s.narration)}</textarea></label>
      <label>Recherche vidéo<input data-query="${i}" value="${esc(s.query)}"></label>
    </div>`).join("");
  document.querySelectorAll("[data-narration]").forEach(el=>el.oninput=e=>scenes[+e.target.dataset.narration].narration=e.target.value);
  document.querySelectorAll("[data-query]").forEach(el=>el.oninput=e=>scenes[+e.target.dataset.query].query=e.target.value);
}

async function searchScene(i){
  const query=scenes[i].query.trim();
  let items=[];
  let errors=[];
  if($("#pexelsKey").value.trim()){
    try{items.push(...await pexelsSearch(query,6));}
    catch(e){errors.push(e.message);}
  }
  if($("#pixabayKey").value.trim()&&(items.length<4)){
    try{items.push(...await pixabaySearch(query,8));}
    catch(e){errors.push(e.message);}
  }
  items=dedupe(items).sort((a,b)=>scoreCandidate(b)-scoreCandidate(a)).slice(0,6);
  searchResults[i]=items;
  if(items.length){
    selections[i]=items[0];
  }
  return {items,errors};
}

$("#searchAllBtn").onclick=async()=>{
  saveKeys();
  if(!$("#pexelsKey").value.trim()&&!$("#pixabayKey").value.trim()){
    toast("Entre au moins une clé gratuite.");
    return;
  }
  $("#resultsCard").classList.remove("hidden");
  $("#prepareCard").classList.remove("hidden");
  $("#audioCard").classList.remove("hidden");
  $("#renderCard").classList.remove("hidden");
  $("#sourcesCard").classList.remove("hidden");
  $("#searchBar").style.width="0%";
  for(let i=0;i<6;i++){
    $("#searchState").textContent=`Recherche de la scène ${i+1}/6 : ${scenes[i].query}`;
    const res=await searchScene(i);
    $("#searchBar").style.width=((i+1)/6*100)+"%";
    renderResults();
    if(!res.items.length&&res.errors.length){
      $("#searchState").textContent=`Scène ${i+1}: ${res.errors.join(" · ")}`;
    }
  }
  const count=selections.filter(Boolean).length;
  $("#searchState").textContent=`${count}/6 scènes ont un clip sélectionné.`;
  renderSources();
  $("#resultsCard").scrollIntoView({behavior:"smooth"});
};

function renderResults(){
  $("#resultsList").innerHTML=scenes.map((s,i)=>{
    const items=searchResults[i];
    const selected=selections[i];
    return `<div class="scene">
      <div class="sceneHead"><b>Scène ${i+1} — ${esc(s.title)}</b><span>${esc(s.query)}</span></div>
      ${items.length?`<div class="candidates">${items.map(c=>candidateHtml(i,c,selected?.id===c.id)).join("")}</div>`:
        `<div class="clipState bad">Aucun résultat. Modifie la recherche ou importe un clip.</div>`}
      <div class="sceneTools">
        <button class="secondary reSearch" data-i="${i}" type="button">Relancer la recherche</button>
        <label class="secondary fileButton">Importer un clip<input class="clipImport" data-i="${i}" type="file" accept="video/*"></label>
      </div>
      <div id="clipState${i}" class="clipState ${prepared[i]?"ok":""}">
        ${prepared[i]?"Clip prêt pour le montage":selected?`Sélectionné : ${esc(selected.provider)} · ${esc(selected.author)}`:"Aucun clip sélectionné"}
      </div>
    </div>`;
  }).join("");

  document.querySelectorAll("[data-candidate]").forEach(btn=>{
    btn.onclick=()=>{
      const i=+btn.dataset.scene;
      const id=btn.dataset.candidate;
      selections[i]=searchResults[i].find(x=>x.id===id)||null;
      if(prepared[i]?.objectUrl)URL.revokeObjectURL(prepared[i].objectUrl);
      prepared[i]=null;
      renderResults();
      renderSources();
    };
  });
  document.querySelectorAll(".reSearch").forEach(btn=>{
    btn.onclick=async()=>{
      const i=+btn.dataset.i;
      $("#searchState").textContent=`Nouvelle recherche de la scène ${i+1}…`;
      await searchScene(i);
      renderResults();
      renderSources();
    };
  });
  document.querySelectorAll(".clipImport").forEach(input=>{
    input.onchange=e=>importLocalClip(+input.dataset.i,e.target.files[0]);
  });
}

function candidateHtml(sceneIndex,c,selected){
  return `<button class="candidate ${selected?"selected":""}" data-scene="${sceneIndex}" data-candidate="${esc(c.id)}" type="button">
    <span class="sourceBadge">${esc(c.provider)}</span>
    ${selected?`<span class="selectedBadge">Choisi</span>`:""}
    <img src="${esc(c.thumbnail)}" alt="Aperçu vidéo ${esc(c.provider)}" loading="lazy">
    <span class="candidateBody">
      <b>${c.width} × ${c.height}</b>
      <small>${Math.round(c.duration)} s · ${esc(c.author)}</small>
    </span>
  </button>`;
}

async function importLocalClip(i,file){
  if(!file)return;
  if(prepared[i]?.objectUrl)URL.revokeObjectURL(prepared[i].objectUrl);
  const objectUrl=URL.createObjectURL(file);
  const candidate={
    id:"local-"+i+"-"+Date.now(),
    provider:"Fichier local",
    providerKey:"local",
    pageUrl:"",
    author:"Utilisateur",
    authorUrl:"",
    duration:5,
    width:0,height:0,
    videoUrl:objectUrl,
    thumbnail:"",
    popularity:0
  };
  selections[i]=candidate;
  try{
    prepared[i]=await preloadVideo(objectUrl,candidate,true);
    prepared[i].objectUrl=objectUrl;
    prepared[i].local=true;
    toast(`Clip local ajouté à la scène ${i+1}.`);
  }catch(e){
    URL.revokeObjectURL(objectUrl);
    prepared[i]=null;
    toast(`Impossible de lire ce clip : ${e.message}`);
  }
  renderResults();
  renderSources();
}

async function fetchAsObjectUrl(url){
  if(window.AndroidBridge&&typeof window.AndroidBridge.downloadToCache==="function"){
    const result=window.AndroidBridge.downloadToCache(url);
    if(result)return {url:result,blob:null,native:true};
  }
  const r=await fetch(url,{cache:"no-store",mode:"cors"});
  if(!r.ok)throw new Error(`Téléchargement HTTP ${r.status}`);
  const blob=await r.blob();
  return {url:URL.createObjectURL(blob),blob,native:false};
}

function preloadVideo(url,candidate,isLocal=false){
  return new Promise((resolve,reject)=>{
    const v=document.createElement("video");
    v.preload="auto";
    v.muted=true;
    v.playsInline=true;
    v.crossOrigin=isLocal?"":"anonymous";
    v.loop=true;
    v.src=url;
    const timeout=setTimeout(()=>reject(new Error("Délai de chargement dépassé.")),30000);
    v.onloadedmetadata=()=>{
      clearTimeout(timeout);
      candidate.duration=Number(v.duration)||candidate.duration||5;
      candidate.width=Number(v.videoWidth)||candidate.width||0;
      candidate.height=Number(v.videoHeight)||candidate.height||0;
      $("#hiddenVideos").appendChild(v);
      resolve({
        candidate,
        video:v,
        objectUrl:isLocal?url:null,
        originClean:isLocal,
        ready:true,
        startOffset:Math.max(0,((Math.abs(hashCode(candidate.id))%100)/100)*Math.max(0,(Number(v.duration)||5)-SCENE_DURATION-.1))
      });
    };
    v.onerror=()=>{clearTimeout(timeout);reject(new Error("Le fichier vidéo ne peut pas être lu."));};
    v.load();
  });
}

function hashCode(s){
  let h=0;
  for(let i=0;i<String(s).length;i++)h=((h<<5)-h)+String(s).charCodeAt(i);
  return h|0;
}

async function prepareScene(i){
  const candidate=selections[i];
  if(!candidate)throw new Error("Aucun clip sélectionné.");
  if(prepared[i])return prepared[i];
  $("#prepareState").textContent=`Clip ${i+1}/6 : téléchargement depuis ${candidate.provider}…`;
  const downloaded=await fetchAsObjectUrl(candidate.videoUrl);
  try{
    const p=await preloadVideo(downloaded.url,candidate,downloaded.url.startsWith("blob:")||downloaded.url.startsWith("file:"));
    p.objectUrl=downloaded.url.startsWith("blob:")?downloaded.url:null;
    p.downloaded=true;
    p.originClean=true;
    prepared[i]=p;
    return p;
  }catch(e){
    if(downloaded.url.startsWith("blob:"))URL.revokeObjectURL(downloaded.url);
    throw e;
  }
}

async function prepareMissing(onlyMissing){
  stopPreparing=false;
  $("#cancelPrepareBtn").disabled=false;
  $("#prepareBtn").disabled=true;
  $("#resumePrepareBtn").disabled=true;
  try{
    for(let i=0;i<6;i++){
      if(stopPreparing)break;
      if(onlyMissing&&prepared[i])continue;
      try{
        await prepareScene(i);
        $("#prepareState").textContent=`Clip ${i+1}/6 prêt.`;
      }catch(e){
        $("#prepareState").textContent=`Échec clip ${i+1}: ${e.message}`;
      }
      $("#prepareBar").style.width=((i+1)/6*100)+"%";
      renderResults();
    }
    const count=prepared.filter(Boolean).length;
    $("#prepareState").textContent=`${count}/6 clips prêts pour le montage.`;
    if(count===6)toast("Les six clips sont prêts.");
  }finally{
    $("#cancelPrepareBtn").disabled=true;
    $("#prepareBtn").disabled=false;
    $("#resumePrepareBtn").disabled=false;
  }
}
$("#prepareBtn").onclick=()=>prepareMissing(false);
$("#resumePrepareBtn").onclick=()=>prepareMissing(true);
$("#cancelPrepareBtn").onclick=()=>{
  stopPreparing=true;
  $("#prepareState").textContent="Arrêt demandé après le clip en cours.";
};

function renderSources(){
  const used=selections.filter(Boolean);
  $("#sourcesList").innerHTML=used.length?used.map((c,i)=>`
    <div class="sourceItem">
      <b>Scène ${i+1} — ${esc(c.provider)}</b>
      <small>${esc(c.author)} · ${Math.round(c.duration||0)} s · ${c.width||"?"} × ${c.height||"?"}</small>
      ${c.pageUrl?`<button data-source-url="${esc(c.pageUrl)}" type="button">Ouvrir la source</button>`:""}
    </div>`).join(""):`<p class="muted">Aucune source sélectionnée.</p>`;
  document.querySelectorAll("[data-source-url]").forEach(btn=>btn.onclick=()=>window.open(btn.dataset.sourceUrl,"_blank"));
}
$("#downloadCreditsBtn").onclick=()=>{
  const text=[
    `ShortFactory V7 — Crédits du projet ${projectId}`,
    "",
    ...selections.map((c,i)=>c?`Scène ${i+1}: ${c.provider} — ${c.author}\n${c.pageUrl||"Fichier local"}`:`Scène ${i+1}: aucune source`)
  ].join("\n\n");
  const blob=new Blob([text],{type:"text/plain;charset=utf-8"});
  const a=document.createElement("a");
  a.href=URL.createObjectURL(blob);
  a.download=`credits-shortfactory-${projectId}.txt`;
  a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),1000);
};

$("#speakBtn").onclick=()=>{
  if(!scenes.length)return;
  if(!("speechSynthesis" in window)){toast("Synthèse vocale indisponible.");return;}
  speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(scenes.map(s=>s.narration).join(" "));
  u.lang="fr-FR";
  u.rate=1.06;
  speechSynthesis.speak(u);
};
$("#audioFile").onchange=e=>{
  const f=e.target.files[0];
  if(!f)return;
  if(audioUrl)URL.revokeObjectURL(audioUrl);
  audioUrl=URL.createObjectURL(f);
  $("#audioPreview").src=audioUrl;
  $("#audioPreview").classList.remove("hidden");
};

function drawPlaceholder(){
  const g=ctx.createLinearGradient(0,0,720,1280);
  g.addColorStop(0,"#203a71");
  g.addColorStop(1,"#070b15");
  ctx.fillStyle=g;
  ctx.fillRect(0,0,720,1280);
  ctx.fillStyle="rgba(85,210,255,.15)";
  for(let i=0;i<28;i++){
    ctx.beginPath();
    ctx.arc((i*137)%760-20,(i*217)%1320-20,12+(i%5)*7,0,Math.PI*2);
    ctx.fill();
  }
  ctx.fillStyle="#fff";
  ctx.textAlign="center";
  ctx.font="700 48px system-ui";
  ctx.fillText("SHORTFACTORY V7",360,600);
  ctx.font="400 25px system-ui";
  ctx.fillStyle="rgba(255,255,255,.7)";
  ctx.fillText("Prépare les six clips pour voir l’aperçu",360,655);
}
drawPlaceholder();

function splitLines(text,max=28){
  const words=String(text||"").split(/\s+/);
  const out=[];
  let line="";
  for(const word of words){
    const test=(line+" "+word).trim();
    if(test.length>max&&line){out.push(line);line=word;}
    else line=test;
  }
  if(line)out.push(line);
  return out.slice(0,7);
}

function drawCover(video,t,alpha=1){
  const cw=canvas.width,ch=canvas.height;
  const vw=video.videoWidth||720,vh=video.videoHeight||1280;
  const vr=vw/vh,cr=cw/ch;
  const zoom=1.03+t*.025;
  let dw,dh;
  if(vr>cr){dh=ch*zoom;dw=dh*vr;}
  else{dw=cw*zoom;dh=dw/vr;}
  const pan=(t-.5)*34;
  ctx.globalAlpha=alpha;
  ctx.drawImage(video,(cw-dw)/2+pan,(ch-dh)/2,dw,dh);
  ctx.globalAlpha=1;
}

function drawOverlay(sceneIndex,localT){
  const scene=scenes[sceneIndex];
  const fade=clamp(Math.min(localT*7,(1-localT)*7),0,1);
  ctx.globalAlpha=fade;
  ctx.fillStyle="rgba(0,0,0,.43)";
  roundRect(ctx,42,170,636,900,34);
  ctx.fill();
  const lines=splitLines(scene?.narration||"",28);
  const lh=65,total=lines.length*lh;
  ctx.fillStyle="#fff";
  ctx.textAlign="center";
  ctx.textBaseline="middle";
  ctx.font="700 46px system-ui";
  lines.forEach((line,i)=>ctx.fillText(line,360,620-total/2+i*lh+lh/2,575));
  ctx.globalAlpha=1;
  if($("#showCredits").checked){
    const c=prepared[sceneIndex]?.candidate||selections[sceneIndex];
    if(c){
      ctx.fillStyle="rgba(0,0,0,.58)";
      roundRect(ctx,28,1190,664,54,16);
      ctx.fill();
      ctx.fillStyle="rgba(255,255,255,.76)";
      ctx.textAlign="center";
      ctx.font="500 17px system-ui";
      ctx.fillText(`${c.provider} · ${c.author}`,360,1217,620);
    }
  }
}

function roundRect(g,x,y,w,h,r){
  g.beginPath();
  g.moveTo(x+r,y);
  g.arcTo(x+w,y,x+w,y+h,r);
  g.arcTo(x+w,y+h,x,y+h,r);
  g.arcTo(x,y+h,x,y,r);
  g.arcTo(x,y,x+w,y,r);
  g.closePath();
}

async function activateScene(index){
  if(currentActive===index)return;
  if(currentActive>=0&&prepared[currentActive]?.video){
    prepared[currentActive].video.pause();
  }
  currentActive=index;
  const p=prepared[index];
  if(!p)return;
  const v=p.video;
  try{
    v.currentTime=Math.min(p.startOffset||0,Math.max(0,(v.duration||5)-.1));
  }catch(e){}
  try{await v.play();}catch(e){}
}

function stopAllVideos(){
  prepared.forEach(p=>p?.video?.pause());
  currentActive=-1;
}

async function runTimeline(onProgress,finish){
  if(prepared.filter(Boolean).length<6)throw new Error("Prépare les six clips avant le montage.");
  stopAllVideos();
  const start=performance.now();
  currentActive=-1;
  return new Promise((resolve,reject)=>{
    const tick=async now=>{
      try{
        const elapsed=(now-start)/1000;
        if(elapsed>=DURATION){
          stopAllVideos();
          finish?.();
          resolve();
          return;
        }
        const index=Math.min(5,Math.floor(elapsed/SCENE_DURATION));
        const local=(elapsed%SCENE_DURATION)/SCENE_DURATION;
        await activateScene(index);
        ctx.fillStyle="#000";
        ctx.fillRect(0,0,720,1280);
        const current=prepared[index]?.video;
        if(current&&current.readyState>=2)drawCover(current,local,1);
        else drawPlaceholder();
        if(index>0&&local<.10){
          const prev=prepared[index-1]?.video;
          if(prev&&prev.readyState>=2){
            drawCover(prev,1,1-local/.10);
          }
        }
        drawOverlay(index,local);
        onProgress?.(elapsed/DURATION,index);
        previewFrame=requestAnimationFrame(tick);
      }catch(e){stopAllVideos();reject(e);}
    };
    previewFrame=requestAnimationFrame(tick);
  });
}

$("#previewBtn").onclick=async()=>{
  if(previewFrame)cancelAnimationFrame(previewFrame);
  try{
    await runTimeline(null,()=>toast("Aperçu terminé."));
  }catch(e){toast(e.message);}
};

function bestMimeType(){
  const types=[
    "video/mp4;codecs=avc1.42E01E,mp4a.40.2",
    "video/webm;codecs=vp9,opus",
    "video/webm;codecs=vp8,opus",
    "video/webm"
  ];
  return types.find(t=>window.MediaRecorder&&MediaRecorder.isTypeSupported(t))||"";
}

$("#renderBtn").onclick=async()=>{
  if(prepared.filter(Boolean).length<6){
    toast("Télécharge ou importe les six clips.");
    return;
  }
  if(!canvas.captureStream||!window.MediaRecorder){
    toast("Cette WebView ne prend pas en charge l’export vidéo.");
    return;
  }
  $("#renderBtn").disabled=true;
  $("#renderProgress").classList.remove("hidden");
  $("#resultVideo").classList.add("hidden");
  $("#downloadBtn").classList.add("hidden");

  const canvasStream=canvas.captureStream(30);
  let finalStream=canvasStream;
  let audio=null,audioContext=null;

  if(audioUrl){
    try{
      audio=new Audio(audioUrl);
      audioContext=new(window.AudioContext||window.webkitAudioContext)();
      const src=audioContext.createMediaElementSource(audio);
      const dest=audioContext.createMediaStreamDestination();
      src.connect(dest);
      src.connect(audioContext.destination);
      finalStream=new MediaStream([...canvasStream.getVideoTracks(),...dest.stream.getAudioTracks()]);
    }catch(e){console.warn("Audio non ajouté",e);}
  }

  const mime=bestMimeType();
  let recorder;
  try{
    recorder=new MediaRecorder(finalStream,mime?{mimeType:mime,videoBitsPerSecond:6000000}:{videoBitsPerSecond:6000000});
  }catch(e){
    $("#renderBtn").disabled=false;
    toast("Impossible d’initialiser l’encodeur vidéo.");
    return;
  }

  const chunks=[];
  recorder.ondataavailable=e=>e.data.size&&chunks.push(e.data);
  const stopped=new Promise(resolve=>recorder.onstop=resolve);
  recorder.start(500);
  if(audio){audio.currentTime=0;audio.play().catch(()=>{});}

  try{
    await runTimeline((p,index)=>{
      $("#renderBar").style.width=(p*100)+"%";
      $("#renderState").textContent=`Rendu ${Math.round(p*100)} % — scène ${index+1}/6`;
    });
    recorder.stop();
    if(audio)audio.pause();
    await stopped;
    if(audioContext)audioContext.close();

    const finalType=recorder.mimeType||mime||"video/webm";
    const blob=new Blob(chunks,{type:finalType});
    const url=URL.createObjectURL(blob);
    $("#resultVideo").src=url;
    $("#resultVideo").classList.remove("hidden");
    const ext=finalType.includes("mp4")?"mp4":"webm";
    $("#downloadBtn").href=url;
    $("#downloadBtn").download=`ShortFactory_V7_${projectId}.${ext}`;
    $("#downloadBtn").classList.remove("hidden");
    $("#renderBar").style.width="100%";
    $("#renderState").textContent=`Vidéo terminée au format ${ext.toUpperCase()}.`;
    toast("Vidéo de 30 secondes terminée.");
  }catch(e){
    if(recorder.state!=="inactive")recorder.stop();
    toast(`Échec du montage : ${e.message}`);
    $("#renderState").textContent=e.message;
  }finally{
    $("#renderBtn").disabled=false;
  }
};

$("#diagBtn").onclick=()=>{
  const report={
    version:"7.0.0",
    date:new Date().toISOString(),
    online:navigator.onLine,
    pexelsKeyPresent:!!$("#pexelsKey").value.trim(),
    pixabayKeyPresent:!!$("#pixabayKey").value.trim(),
    scenes:scenes.length,
    selected:selections.filter(Boolean).length,
    prepared:prepared.filter(Boolean).length,
    mediaRecorder:!!window.MediaRecorder,
    canvasCapture:!!canvas.captureStream,
    mimeType:bestMimeType()||"none",
    androidBridge:!!window.AndroidBridge,
    userAgent:navigator.userAgent
  };
  $("#diagnostic").textContent=JSON.stringify(report,null,2);
  const blob=new Blob([JSON.stringify(report,null,2)],{type:"application/json"});
  const a=document.createElement("a");
  a.href=URL.createObjectURL(blob);
  a.download=`diagnostic-shortfactory-v7-${Date.now()}.json`;
  a.click();
  setTimeout(()=>URL.revokeObjectURL(a.href),1000);
};

})();
