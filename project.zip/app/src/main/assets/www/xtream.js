(function(){
  const timeoutFetch=async(url,ms=22000)=>{const controller=new AbortController();const id=setTimeout(()=>controller.abort(),ms);try{const res=await fetch(url,{signal:controller.signal,cache:'no-store',redirect:'follow'});if(!res.ok)throw new Error('HTTP '+res.status);const text=await res.text();try{return JSON.parse(text)}catch{throw new Error('Réponse serveur invalide')}}finally{clearTimeout(id)}};
  const normalizeServer=value=>{
    let s=String(value||'').trim().replace(/\/+$/,'');
    if(!/^https?:\/\//i.test(s))s='http://'+s;
    return s;
  };
  const q=value=>encodeURIComponent(String(value??''));
  class XtreamClient{
    constructor(account){this.account={...account,server:normalizeServer(account.server)}}
    apiUrl(action='',extra={}){const {server,username,password}=this.account;const p=new URLSearchParams({username,password});if(action)p.set('action',action);Object.entries(extra).forEach(([k,v])=>p.set(k,v));return `${server}/player_api.php?${p}`}
    async request(action='',extra={}){return timeoutFetch(this.apiUrl(action,extra))}
    async authenticate(){
      const data=await this.request();
      if(!data?.user_info)throw new Error('Compte Xtream non reconnu');
      const auth=String(data.user_info.auth??'1');
      if(auth!=='1')throw new Error('Identifiants refusés par le serveur');
      return data;
    }
    async loadCatalog(){
      const calls={liveCategories:'get_live_categories',movieCategories:'get_vod_categories',seriesCategories:'get_series_categories',live:'get_live_streams',movies:'get_vod_streams',series:'get_series'};
      const entries=await Promise.all(Object.entries(calls).map(async([key,action])=>{try{return [key,await this.request(action)]}catch(error){return [key,[]]}}));
      return Object.fromEntries(entries.map(([k,v])=>[k,Array.isArray(v)?v:[]]));
    }
    getVodInfo(id){return this.request('get_vod_info',{vod_id:id})}
    getSeriesInfo(id){return this.request('get_series_info',{series_id:id})}
    getShortEpg(id,limit=6){return this.request('get_short_epg',{stream_id:id,limit})}
    basePath(){const a=this.account;return {server:a.server,u:q(a.username),p:q(a.password)}}
    liveCandidates(item,format='m3u8'){
      const b=this.basePath(),id=item.stream_id||item.id;const direct=item.direct_source||item.stream_url;const exts=[format,format==='m3u8'?'ts':'m3u8'];return unique([direct,...exts.map(ext=>`${b.server}/live/${b.u}/${b.p}/${id}.${ext}`)])
    }
    movieCandidates(item,info={}){
      const b=this.basePath(),id=item.stream_id||item.id;const data=info.movie_data||{};const direct=data.direct_source||info.info?.direct_source||item.direct_source;const ext=data.container_extension||item.container_extension||'mp4';return unique([direct,`${b.server}/movie/${b.u}/${b.p}/${id}.${ext}`,`${b.server}/movie/${b.u}/${b.p}/${id}.mp4`,`${b.server}/movie/${b.u}/${b.p}/${id}.m3u8`,`${b.server}/movie/${b.u}/${b.p}/${id}.mkv`])
    }
    episodeCandidates(ep){
      const b=this.basePath(),id=ep.id||ep.stream_id;const ext=ep.container_extension||'mp4';return unique([ep.direct_source,`${b.server}/series/${b.u}/${b.p}/${id}.${ext}`,`${b.server}/series/${b.u}/${b.p}/${id}.mp4`,`${b.server}/series/${b.u}/${b.p}/${id}.m3u8`,`${b.server}/series/${b.u}/${b.p}/${id}.mkv`])
    }
  }
  function unique(values){return [...new Set(values.filter(v=>typeof v==='string'&&/^https?:\/\//i.test(v)))]}
  function expiryInfo(userInfo={}){
    const raw=userInfo.exp_date;let date=null;if(raw&&raw!=='null'&&raw!=='0'){const n=Number(raw);date=Number.isFinite(n)?new Date(n*1000):new Date(raw);if(Number.isNaN(date.getTime()))date=null}
    if(!date)return {date:null,label:'Sans date communiquée',remaining:'Non communiqué',days:null,expired:false};
    const diff=date.getTime()-Date.now(),days=Math.ceil(diff/86400000),expired=diff<=0;
    return {date,label:date.toLocaleDateString('fr-FR',{day:'2-digit',month:'2-digit',year:'numeric'}),remaining:expired?'Expiré':days===0?'Moins de 24 h':`${days} jour${days>1?'s':''}`,days,expired};
  }
  window.Xtream={XtreamClient,normalizeServer,expiryInfo};
})();
