(function(){
  const parseResult=value=>{try{return typeof value==='string'?JSON.parse(value):value}catch{return value}};
  function android(){return window.AndroidApp||null}
  function available(){return !!android()}
  function nativePlayerAvailable(){
    try{if(android()?.supportsNativeIptv)return !!android().supportsNativeIptv()}catch{}
    try{const cap=parseResult(window.NativeAndroidPlayer?.getCapabilities?.());return !!cap?.play}catch{}
    return false;
  }
  function saveSecret(key,value){
    try{if(android()?.saveSecret)android().saveSecret(String(key),String(value??''));return true}catch{return false}
  }
  function loadSecret(key){
    try{if(android()?.loadSecret)return String(android().loadSecret(String(key))||'')}catch{}
    return '';
  }
  function play(payload){
    const p=payload||{};
    if(android()?.playNative){android().playNative(String(p.url),String(p.title||'Lecture'),String(p.type||'video'),String(p.poster||''));return true}
    if(window.NativeAndroidPlayer?.play){window.NativeAndroidPlayer.play(JSON.stringify(p));return true}
    return false;
  }
  function cast(payload){
    const p=payload||{};
    if(android()?.castNative){android().castNative(String(p.url),String(p.title||'Diffusion'),String(p.mime||'application/x-mpegURL'),String(p.poster||''));return true}
    if(window.NativeAndroidCast?.cast){window.NativeAndroidCast.cast(JSON.stringify(p));return true}
    if(window.NativeAndroidCast?.requestSession){window.NativeAndroidCast.requestSession(JSON.stringify(p));return true}
    return false;
  }
  function toast(message){try{if(android()?.showToast){android().showToast(String(message));return}}catch{};console.log(message)}
  window.PrimeNative={available,nativePlayerAvailable,saveSecret,loadSecret,play,cast,toast};
})();
