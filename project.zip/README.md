# Shortfactory V4

Application Android générée depuis un projet HTML.

## Compilation automatique

1. Crée un dépôt GitHub.
2. Décompresse ce projet dans le dépôt.
3. Pousse les fichiers sur la branche `main`.
4. Ouvre l’onglet **Actions**.
5. Le workflow **Build Android APK** compile automatiquement l’application.
6. L’APK est disponible dans **Releases**, sous le tag `generated-apk`.

## Compilation avec Android Studio

Ouvre ce dossier comme projet Android. Le projet utilise :

- Android Gradle Plugin 8.7.3
- Gradle 8.9
- Java 17
- compileSdk/targetSdk 35
- WebView Android native sans dépendance externe
- minSdk 24

Sans Gradle Wrapper inclus, Android Studio peut utiliser une installation locale de Gradle 8.9. En ligne de commande :

```bash
gradle :app:assembleDebug
```

L’APK est créé dans :

`app/build/outputs/apk/debug/app-debug.apk`

## Pont JavaScript natif

L’objet `AndroidApp` est accessible depuis le contenu local :

```javascript
AndroidApp.showToast("Bonjour");
AndroidApp.share("Texte à partager");
AndroidApp.copyText("Texte");
AndroidApp.vibrate(100);
AndroidApp.openUrl("https://example.com");
```

Le fichier `android-bridge.js` fournit aussi une couche compatible navigateur.
